/* Serrenya Dice – interface and real-time synchronisation. No build step required. */
(() => {
'use strict';
const $=id=>document.getElementById(id);
const all=(selector,root=document)=>[...root.querySelectorAll(selector)];
const DEFAULT_PHYSICS={gravity:17,bounce:.43,friction:.31,force:8,spin:10,duration:2900,maxVisible:12};
const PRESETS={
  arcane:{base:'#2d2450',edge:'#e8b96b',ink:'#fff4d8',glow:'#a783ef',metalness:.52},
  obsidian:{base:'#14141f',edge:'#a49eaf',ink:'#eee4f2',glow:'#8b8daf',metalness:.82},
  ember:{base:'#681e2b',edge:'#e8a24d',ink:'#ffebcf',glow:'#f17b3d',metalness:.68},
  frost:{base:'#216286',edge:'#c8f3f5',ink:'#fffdf5',glow:'#80d4ff',metalness:.63},
  forest:{base:'#1f483e',edge:'#d1c98a',ink:'#f5f7df',glow:'#82cb8b',metalness:.35},
  royal:{base:'#623d75',edge:'#f5d38b',ink:'#fff7e6',glow:'#e5a4f7',metalness:.87}
};
const HINTS={4:'Tetraeder · vier Seiten',6:'Klassischer sechsseitiger Würfel',8:'Oktaeder · acht Seiten',10:'Zehnseitiger Würfel',12:'Dodekaeder · zwölf Seiten',20:'Zwanzigseitiger Schicksalswürfel',100:'Prozentwurf · zwei W10 (Zehner und Einer)'};
const MODE_LABELS={arcane:'ARKAN',obsidian:'OBSIDIAN',ember:'GLUT',frost:'FROST',forest:'WALD',royal:'ROYAL',custom:'EIGENES DESIGN'};
let currentScreen='welcome',session=null,socket=null,connectionGeneration=0,sequence=0,requests=new Map(),connected=false,roomState=null,reconnectTimer=null,noticeTimer=null,toastTimer=null,settingsTimer=null,lastAnnouncementId=null;
let hostStage,playerStage,heroStage,selectedSides=20,selectedCount=1,style={...PRESETS.arcane,finish:'arcane'};
function getStorage(key,sessionMode=false){try{return JSON.parse((sessionMode?sessionStorage:localStorage).getItem(key));}catch{return null;}}
function setStorage(key,value,sessionMode=false){try{(sessionMode?sessionStorage:localStorage).setItem(key,JSON.stringify(value));}catch{}}
function rmStorage(key,sessionMode=false){try{(sessionMode?sessionStorage:localStorage).removeItem(key);}catch{}}
function uiScreen(name){currentScreen=name;for(const id of ['welcome','host','player'])$(id).hidden=id!==name;if(name==='host'&&!hostStage)hostStage=new SerrenyaDiceEngine.DiceStage($('board-canvas'));if(name==='player'&&!playerStage)playerStage=new SerrenyaDiceEngine.DiceStage($('player-preview'),{preview:true});if(name==='welcome'&&!heroStage)heroStage=new SerrenyaDiceEngine.DiceStage($('hero-canvas'),{preview:true});}
function toast(message,error=false){const el=$('toast');el.textContent=message;el.classList.toggle('error',error);el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3600);}
function humanError(err){return (err&&err.message)||String(err)||'Unbekannter Fehler';}
function setConnection(isOnline){connected=isOnline;for(const mode of ['host','player']){const led=$(`${mode}-connection`),text=$(`${mode}-connection-text`);led.classList.toggle('online',isOnline);text.textContent=isOnline?'Verbunden':'Nicht verbunden';}const btn=$('roll-button');btn.disabled=!isOnline;if(currentScreen==='player'&&!isOnline)$('roll-feedback').textContent='Verbindung zum Würfeltisch wird aufgebaut ...';}
function currentJoinUrl(code){const url=new URL('/',location.origin);url.searchParams.set('join',code);return url.toString();}
async function copyText(s){try{await navigator.clipboard.writeText(s);toast('In die Zwischenablage kopiert ✦');}catch{window.prompt('Link zum Kopieren:',s);}}
function roomCode(c){return /^[A-HJ-NP-Z2-9]{6}$/.test(c);}
function announce(name,number,detail){$('announcement-name').textContent=name;$('announcement-number').textContent=number;$('announcement-detail').textContent=detail;}
function applyPhysics(physics){for(const [name,val] of Object.entries(physics)){const input=document.querySelector(`[data-physics="${name}"]`);if(input)input.value=val;}updatePhysicsOutputs();if(hostStage)hostStage.setPhysics(physics);}
function updatePhysicsOutputs(){for(const inp of all('[data-physics]')){const key=inp.dataset.physics;const n=+inp.value;const out=document.querySelector(`[data-output="${key}"]`);if(out)out.textContent=['bounce','friction'].includes(key)?Math.round(n*100)+'%':key==='duration'?(n/1000).toFixed(1)+' s':String(n);}}
function collectPhysics(){const out={};for(const inp of all('[data-physics]'))out[inp.dataset.physics]=+inp.value;return out;}
function renderMembers(members=[]){$('player-count').textContent=members.filter(m=>m.role==='player').length;const target=$('member-list');target.replaceChildren();if(!members.length){appendEmpty(target,'Noch keine Abenteurer verbunden.');return;}for(const m of members){const row=document.createElement('div');row.className='member';const avatar=document.createElement('span');avatar.className='member-avatar';avatar.textContent=(m.name||'?')[0].toLocaleUpperCase('de-CH');const info=document.createElement('div');info.className='member-copy';const name=document.createElement('strong');name.textContent=m.name;const role=document.createElement('small');role.textContent=m.role==='host'?'Spielleitung':'Abenteurer/in';info.append(name,role);const led=document.createElement('span');led.className='member-connection';row.append(avatar,info,led);target.append(row);}}
function appendEmpty(parent,message){const el=document.createElement('div');el.className='empty-message';el.textContent=message;parent.append(el);}
function renderHistory(){const recent=(roomState?.recent||[]).slice(-20).reverse();const history=$('host-history');history.replaceChildren();if(!recent.length)appendEmpty(history,'Hier erscheinen die Würfe.');for(const roll of recent){const row=document.createElement('div');row.className='history-row';const info=document.createElement('div');info.className='history-person';const n=document.createElement('strong');n.textContent=roll.name;const desc=document.createElement('small');desc.textContent=roll.notation+' · '+new Date(roll.createdAt).toLocaleTimeString('de-CH',{hour:'2-digit',minute:'2-digit'});info.append(n,desc);const result=document.createElement('span');result.className='history-result';result.textContent=roll.total;row.append(info,result);history.append(row);}const yours=recent.filter(r=>r.name===session?.name).slice(0,8);const player=$('player-history');player.replaceChildren();if(!yours.length)appendEmpty(player,'Noch keine Würfe.');for(const r of yours){const row=document.createElement('div');row.className='history-row';const info=document.createElement('div');info.className='history-person';const label=document.createElement('strong');label.textContent=r.notation;const sub=document.createElement('small');sub.textContent=new Date(r.createdAt).toLocaleTimeString('de-CH',{hour:'2-digit',minute:'2-digit'});info.append(label,sub);const result=document.createElement('div');result.className='history-result';result.textContent=r.total;row.append(info,result);player.append(row);}}
function updateHostRoom(room){roomState=room;$('room-code').textContent=room.code;$('stage-placeholder').hidden=!!room.recent.length;const join=currentJoinUrl(room.code);$('room-qr').src='https://api.qrserver.com/v1/create-qr-code/?size=270x270&margin=10&data='+encodeURIComponent(join);$('room-qr').onerror=()=>{$('room-qr').style.opacity='.22';$('room-qr').title='QR-Code nicht verfügbar. Bitte Raumcode verwenden.'};applyPhysics(room.physics);renderMembers(room.members);renderHistory();}
function handleRoll(roll){if(!roomState)return;roomState.recent.push({id:roll.id,name:roll.name,playerId:roll.playerId,notation:roll.notation,total:roll.total,createdAt:roll.createdAt,dice:roll.dice.map(x=>x.label)});roomState.recent=roomState.recent.slice(-30);renderHistory();
 if(currentScreen==='host'){
   hostStage.addRoll(roll);$('stage-placeholder').hidden=true;
   lastAnnouncementId=roll.id;announce(roll.name.toLocaleUpperCase('de-CH')+' WÜRFELT ...','✦',roll.notation+' · DIE WÜRFEL ROLLEN');
   clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>{if(lastAnnouncementId!==roll.id)return;const faces=roll.dice.map(d=>d.label).join(' · ');announce(roll.name.toLocaleUpperCase('de-CH')+' WIRFT '+roll.notation,roll.total.toString(),roll.sides===100?`${roll.count} Prozentwurf/-würfe`:roll.count>1?'Einzelwürfel: '+faces:'Ergebnis: '+faces);},roll.physics?.duration||2900);
 }
 if(currentScreen==='player'&&roll.name===session?.name){$('roll-feedback').textContent=`${roll.notation} · Ergebnis ${roll.total} – erscheint auf dem Hauptdisplay!`;} }
function socketUrl(){return (location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws';}
function send(type,payload){return new Promise((resolve,reject)=>{if(!socket||socket.readyState!==WebSocket.OPEN)return reject(new Error('Keine Verbindung zum Server.'));const ref='m'+(++sequence);const timeout=setTimeout(()=>{requests.delete(ref);reject(new Error('Zeitüberschreitung bei der Serveranfrage.'));},10000);requests.set(ref,{resolve,reject,timeout});socket.send(JSON.stringify({type,ref,payload}));});}
function handleSocketEvent(message){if(message.type==='ack'){const entry=requests.get(message.ref);if(!entry)return;requests.delete(message.ref);clearTimeout(entry.timeout);if(message.ok)entry.resolve(message);else entry.reject(new Error(message.error||'Aktion fehlgeschlagen'));return;}
 if(message.type==='room:members'){if(roomState){roomState.members=message.members||[];roomState.hostOnline=message.hostOnline;renderMembers(roomState.members);}if(session?.role==='player'&&!message.hostOnline){$('roll-feedback').textContent='Das Hauptdisplay ist offline. Würfe werden weiterhin gespeichert, sobald der Server erreichbar ist.';}return;}
 if(message.type==='room:settings'){if(roomState){roomState.physics=message.physics;applyPhysics(message.physics);}return;}
 if(message.type==='roll:started'){handleRoll(message.roll);return;}
 if(message.type==='room:cleared'){if(roomState){roomState.recent=[];renderHistory();}if(hostStage)hostStage.clear();$('stage-placeholder').hidden=false;announce('DER TISCH IST BEREIT','✧','Jeder Wurf zählt.');return;}
 if(message.type==='error')toast(message.error||'Serverfehler',true);
}
async function connect(){if(!session)return;const generation=++connectionGeneration;clearTimeout(reconnectTimer);try{if(socket){socket.onclose=null;socket.close();}}catch{}setConnection(false);
 try{socket=new WebSocket(socketUrl());}catch(e){toast('WebSocket-Verbindung konnte nicht hergestellt werden.',true);scheduleReconnect(generation);return;}
 const ws=socket;
 ws.onopen=async()=>{if(generation!==connectionGeneration)return;try{const joined=await send('room:join',session);if(generation!==connectionGeneration)return;setConnection(true);roomState=joined.room;if(session.role==='host')updateHostRoom(joined.room);else{$('player-room-label').textContent='DEIN RAUM · '+joined.room.code;renderHistory();$('roll-feedback').textContent='Du bist verbunden. Deine Würfel sind bereit!';} }catch(e){setConnection(false);toast(humanError(e),true);if(/nicht gefunden|Zugriff/.test(humanError(e))){goHome();}else{try{ws.close();}catch{}}}};
 ws.onmessage=event=>{let message;try{message=JSON.parse(event.data);}catch{return;}handleSocketEvent(message);};
 ws.onclose=()=>{if(generation!==connectionGeneration)return;setConnection(false);for(const [ref,pending] of requests){clearTimeout(pending.timeout);pending.reject(new Error('Verbindung unterbrochen'));requests.delete(ref);}scheduleReconnect(generation);};
 ws.onerror=()=>{if(generation===connectionGeneration)setConnection(false);};
}
function scheduleReconnect(generation){if(generation!==connectionGeneration||!session)return;clearTimeout(reconnectTimer);reconnectTimer=setTimeout(()=>{if(generation===connectionGeneration)connect();},2400);}
function goHome(){connectionGeneration++;clearTimeout(reconnectTimer);clearTimeout(noticeTimer);if(socket){socket.onclose=null;socket.close();socket=null;}session=null;roomState=null;setConnection(false);history.replaceState(null,'','/');uiScreen('welcome');}
async function createRoom(){const btn=$('create-room');btn.disabled=true;const previous=btn.textContent;btn.textContent='✦ PORTAL ÖFFNET SICH ...';try{const res=await fetch('/api/rooms',{method:'POST'});const data=await res.json();if(!res.ok)throw new Error(data.error||'Raum konnte nicht erstellt werden.');session={role:'host',code:data.code,token:data.hostToken};setStorage('serrenya-active-host',session,true);history.replaceState(null,'','/?table='+encodeURIComponent(data.code));uiScreen('host');announce('DER TISCH IST BEREIT','✧','Jeder Wurf zählt.');connect();}catch(e){toast(humanError(e),true);}finally{btn.disabled=false;btn.textContent=previous;}}
function requestJoin(code){const sanitized=String(code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);$('join-code').value=sanitized;if(!roomCode(sanitized)){toast('Bitte einen gültigen sechsstelligen Raumcode eingeben.',true);return;}const remembered=getStorage('serrenya-player');if(remembered?.name){startPlayer(sanitized,remembered.name);}else{$('nickname-modal').hidden=false;$('nickname').focus();}}
function startPlayer(code,name){const cleaned=String(name||'').trim().slice(0,26);if(!cleaned){$('nickname-modal').hidden=false;return;}$('nickname-modal').hidden=true;session={role:'player',code,name:cleaned};setStorage('serrenya-player',{name:cleaned});history.replaceState(null,'','/?join='+encodeURIComponent(code));uiScreen('player');$('player-room-label').textContent='DEIN RAUM · '+code;connect();}
function setSides(sides){selectedSides=sides;for(const button of all('.dice-type'))button.classList.toggle('active',Number(button.dataset.sides)===sides);$('preview-type').textContent='W'+sides;$('dice-hint').textContent=HINTS[sides];if(playerStage)playerStage.setPreview(sides,style);saveDesign();}
function setCount(n){selectedCount=Math.max(1,Math.min(8,n));$('dice-count').textContent=selectedCount;$('count-minus').disabled=selectedCount===1;$('count-plus').disabled=selectedCount===8;saveDesign();}
function updateStyleInputs(){const keys={base:'color-base',edge:'color-edge',ink:'color-ink',glow:'color-glow'};for(const [key,id] of Object.entries(keys))$(id).value=style[key];$('metalness').value=style.metalness;$('metalness-value').textContent=Math.round(style.metalness*100)+'%';for(const button of all('.preset'))button.classList.toggle('active',button.dataset.preset===style.finish);$('preview-finish').textContent=MODE_LABELS[style.finish]||'EIGENES DESIGN';if(playerStage)playerStage.setPreview(selectedSides,style);}
function saveDesign(){setStorage('serrenya-design',{style,sides:selectedSides,count:selectedCount});}
function selectPreset(name){if(!PRESETS[name])return;style={...PRESETS[name],finish:name};updateStyleInputs();saveDesign();}
function customStyle(){style={base:$('color-base').value,edge:$('color-edge').value,ink:$('color-ink').value,glow:$('color-glow').value,metalness:+$('metalness').value,finish:'custom'};updateStyleInputs();saveDesign();}
async function roll(){if(!connected||!session)return;const btn=$('roll-button');btn.disabled=true;const sides=selectedSides,count=selectedCount;try{await send('roll:request',{sides,count,style});$('roll-feedback').textContent=`${count}W${sides} wird geworfen ...`;setTimeout(()=>{btn.disabled=!connected;},900);}catch(e){btn.disabled=!connected;toast(humanError(e),true);$('roll-feedback').textContent=humanError(e);}}
function bindEvents(){
 $('create-room').addEventListener('click',createRoom);
 $('join-form').addEventListener('submit',event=>{event.preventDefault();requestJoin($('join-code').value);});
 $('join-code').addEventListener('input',e=>{e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);});
 $('nickname-form').addEventListener('submit',e=>{e.preventDefault();startPlayer($('join-code').value,$('nickname').value);});
 $('nickname-cancel').addEventListener('click',()=>{$('nickname-modal').hidden=true;});
 for(const a of all('[data-action="home"]'))a.addEventListener('click',e=>{e.preventDefault();goHome();});
 $('copy-code').addEventListener('click',()=>copyText(session?.code||''));
 $('copy-link').addEventListener('click',()=>copyText(currentJoinUrl(session?.code||'')));
 $('fullscreen').addEventListener('click',()=>{if(document.fullscreenElement)document.exitFullscreen?.();else document.documentElement.requestFullscreen?.().catch(()=>toast('Vollbildmodus ist nicht verfügbar.'));});
 for(const inp of all('[data-physics]'))inp.addEventListener('input',()=>{updatePhysicsOutputs();clearTimeout(settingsTimer);settingsTimer=setTimeout(()=>{const physics=collectPhysics();if(hostStage)hostStage.setPhysics(physics);if(session?.role==='host'&&connected)send('room:settings',physics).catch(e=>toast(humanError(e),true));},100);});
 $('physics-reset').addEventListener('click',()=>{applyPhysics(DEFAULT_PHYSICS);if(connected)send('room:settings',DEFAULT_PHYSICS).catch(e=>toast(humanError(e),true));});
 $('test-roll').addEventListener('click',async()=>{if(!connected)return toast('Bitte Verbindung abwarten.',true);try{await send('roll:request',{sides:20,count:1,style:{...PRESETS.arcane,finish:'arcane'}});}catch(e){toast(humanError(e),true);}});
 $('clear-board').addEventListener('click',()=>{if(!connected)return toast('Keine Verbindung.',true);send('room:clear',{}).catch(e=>toast(humanError(e),true));});
 for(const el of all('.dice-type'))el.addEventListener('click',()=>setSides(Number(el.dataset.sides)));
 $('count-minus').addEventListener('click',()=>setCount(selectedCount-1));$('count-plus').addEventListener('click',()=>setCount(selectedCount+1));
 for(const btn of all('.preset'))btn.addEventListener('click',()=>selectPreset(btn.dataset.preset));
 for(const id of ['color-base','color-edge','color-ink','color-glow','metalness'])$(id).addEventListener('input',customStyle);
 $('roll-button').addEventListener('click',roll);
 document.addEventListener('keydown',e=>{if((e.key===' '||e.key==='Enter')&&currentScreen==='player'&&!['INPUT','TEXTAREA','BUTTON'].includes(document.activeElement?.tagName)){e.preventDefault();roll();}});
}
function init(){uiScreen('welcome');bindEvents();const saved=getStorage('serrenya-design');if(saved){style={...PRESETS.arcane,...saved.style};selectedSides=[4,6,8,10,12,20,100].includes(saved.sides)?saved.sides:20;selectedCount=Math.max(1,Math.min(8,Number(saved.count)||1));}updateStyleInputs();setSides(selectedSides);setCount(selectedCount);
 const params=new URLSearchParams(location.search),join=params.get('join'),table=params.get('table');
 if(join){const code=join.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);$('join-code').value=code;if(roomCode(code)){const known=getStorage('serrenya-player');if(known?.name)startPlayer(code,known.name);else{$('nickname-modal').hidden=false;$('nickname').focus();}}}
 else if(table){const savedHost=getStorage('serrenya-active-host',true);if(savedHost?.code===table&&savedHost.token){session=savedHost;uiScreen('host');connect();}}
}
init();
})();
