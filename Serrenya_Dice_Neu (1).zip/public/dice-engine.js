/* Serrenya Dice — self-contained 3D polyhedron renderer and configurable throw animation.
   Uses HTML Canvas 2D, real 3D coordinates/quaternions, no external dependencies. */
(() => {
'use strict';
const PI = Math.PI, TAU = PI*2, PHI=(1+Math.sqrt(5))/2;
const V={add:(a,b)=>a.map((x,i)=>x+b[i]),sub:(a,b)=>a.map((x,i)=>x-b[i]), mul:(a,s)=>a.map(x=>x*s),dot:(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0), cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm:a=>Math.hypot(...a),unit:a=>{const m=Math.hypot(...a)||1;return a.map(x=>x/m);}};
const Q={mul:(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]],axis:(a,r)=>{const n=V.unit(a),s=Math.sin(r/2);return [...V.mul(n,s),Math.cos(r/2)];},rot:(q,p)=>{const u=q.slice(0,3),s=q[3];return V.add(V.add(V.mul(u,2*V.dot(u,p)),V.mul(p,s*s-V.dot(u,u))),V.mul(V.cross(u,p),2*s));},to:(a,b)=>{const x=V.unit(a),y=V.unit(b),d=V.dot(x,y);if(d<-.999999)return Q.axis(V.unit(V.cross(x,Math.abs(x[0])<.8?[1,0,0]:[0,1,0])),PI);const c=V.cross(x,y);return V.unit([...c,1+d]);},slerp:(a,b,t)=>{let dot=a.reduce((v,x,i)=>v+x*b[i],0);if(dot<0){b=b.map(v=>-v);dot=-dot;}if(dot>.9995)return V.unit(a.map((v,i)=>v*(1-t)+b[i]*t));const th=Math.acos(Math.max(-1,Math.min(1,dot))),s=Math.sin(th);return a.map((v,i)=>(v*Math.sin((1-t)*th)+b[i]*Math.sin(t*th))/s);}};
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
const smooth=t=>t*t*(3-2*t);
function hull(vertices){
  const normVerts=vertices.map(v=>V.mul(v,1/Math.max(...vertices.map(V.norm))));
  const planes=[];
  for(let i=0;i<normVerts.length;i++)for(let j=i+1;j<normVerts.length;j++)for(let k=j+1;k<normVerts.length;k++){
    let n=V.cross(V.sub(normVerts[j],normVerts[i]),V.sub(normVerts[k],normVerts[i]));if(V.norm(n)<1e-5)continue;n=V.unit(n);let above=0,below=0;for(const p of normVerts){const side=V.dot(n,V.sub(p,normVerts[i]));if(side>1e-5)above++;if(side< -1e-5)below++;if(above&&below)break;}
    if(above&&below)continue;if(above)n=V.mul(n,-1);
    const distance=V.dot(n,normVerts[i]);if(planes.some(p=>V.dot(p.normal,n)>.9999&&Math.abs(p.distance-distance)<1e-4))continue;
    planes.push({normal:n,distance});
  }
  const faces=planes.map(p=>{
    const indices=normVerts.map((v,i)=>({v,i})).filter(o=>Math.abs(V.dot(p.normal,o.v)-p.distance)<1e-4).map(o=>o.i);
    const center=V.mul(indices.reduce((s,i)=>V.add(s,normVerts[i]),[0,0,0]),1/indices.length);
    const xaxis=V.unit(V.sub(normVerts[indices[0]],center)),yaxis=V.cross(p.normal,xaxis);
    indices.sort((a,b)=>Math.atan2(V.dot(V.sub(normVerts[a],center),yaxis),V.dot(V.sub(normVerts[a],center),xaxis))-Math.atan2(V.dot(V.sub(normVerts[b],center),yaxis),V.dot(V.sub(normVerts[b],center),xaxis)));
    return {indices,center,normal:p.normal};
  }).filter(f=>f.indices.length>=3);
  return {vertices:normVerts,faces};
}
function makeGeometry(sides){
  let v=[];
  if(sides===4) v=[[1,1,1],[-1,-1,1],[-1,1,-1],[1,-1,-1]];
  else if(sides===6)for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1])v.push([x,y,z]);
  else if(sides===8) v=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  else if(sides===20){for(const a of [-1,1])for(const b of [-1,1])v.push([0,a,b*PHI],[a,b*PHI,0],[a*PHI,0,b]);}
  else if(sides===12){for(const a of [-1,1])for(const b of [-1,1])for(const c of [-1,1])v.push([a,b,c]);for(const a of [-1,1])for(const b of [-1,1])v.push([0,a/PHI,b*PHI],[a/PHI,b*PHI,0],[a*PHI,0,b/PHI]);}
  else if(sides===10){const top=1.4,ring=top*(1-Math.cos(PI/5))/(1+Math.cos(PI/5));v.push([0,0,top],[0,0,-top]);for(let i=0;i<5;i++){const a=TAU*i/5;v.push([Math.cos(a),Math.sin(a),ring]);v.push([Math.cos(a+PI/5),Math.sin(a+PI/5),-ring]);}}
  const geometry=hull(v);
  // Sort face ordering in a deterministic way so faceIndex selected server-side is stable.
  geometry.faces.sort((a,b)=>b.normal[2]-a.normal[2]||b.normal[1]-a.normal[1]||a.normal[0]-b.normal[0]);
  return geometry;
}
const GEOMS=Object.fromEntries([4,6,8,10,12,20].map(n=>[n,makeGeometry(n)]));
function hex(color){const x=/^#[a-f0-9]{6}$/i.test(color||'')?color:'#342355';return [parseInt(x.slice(1,3),16),parseInt(x.slice(3,5),16),parseInt(x.slice(5,7),16)];}
function tint(color,l){const c=hex(color);return `rgb(${c.map(v=>Math.round(clamp(v*l,0,255))).join(',')})`;}
function rgba(color,opacity){const c=hex(color);return `rgba(${c.join(',')},${opacity})`;}
function textFont(px){return `700 ${Math.round(px)}px Georgia, 'Times New Roman', serif`;}
function shape(ctx,pts){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();}
function drawRune(ctx,x,y,r,color,alpha=1){ctx.save();ctx.strokeStyle=rgba(color,.22*alpha);ctx.lineWidth=1;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.stroke();ctx.beginPath();ctx.arc(x,y,r*.83,0,TAU);ctx.stroke();for(let k=0;k<12;k++){const t=k*TAU/12;ctx.beginPath();ctx.moveTo(x+Math.cos(t)*r*.88,y+Math.sin(t)*r*.88);ctx.lineTo(x+Math.cos(t)*r*.96,y+Math.sin(t)*r*.96);ctx.stroke();}ctx.restore();}
class DiceStage {
 constructor(canvas,{preview=false}={}){
   this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:true});this.preview=preview;this.dice=[];this.maxVisible=12;this.physics={gravity:17,bounce:.43,friction:.31,force:8,spin:10,duration:2900};this.lastWidth=0;this.lastHeight=0;this.active=true;this.style={base:'#2d2450',edge:'#e8b96b',ink:'#fff4d8',glow:'#a783ef',metalness:.52};this.previewSides=20;this.idleTime=performance.now();this.raf=0;this.loop=this.loop.bind(this);this.raf=requestAnimationFrame(this.loop);
 }
 resize(){const rect=this.canvas.getBoundingClientRect(),w=Math.max(1,Math.round(rect.width)),h=Math.max(1,Math.round(rect.height)),dpr=Math.min(devicePixelRatio||1,2);if(this.canvas.width!==Math.round(w*dpr)||this.canvas.height!==Math.round(h*dpr)){this.canvas.width=Math.round(w*dpr);this.canvas.height=Math.round(h*dpr);}this.ctx.setTransform(dpr,0,0,dpr,0,0);this.w=w;this.h=h;}
 setPhysics(p){this.physics={...this.physics,...p};this.maxVisible=p.maxVisible??this.maxVisible;this.dice=this.dice.slice(-this.maxVisible);}
 setPreview(sides,style){this.previewSides=sides===100?10:sides;this.style={...this.style,...style};}
 clear(){this.dice=[];}
 addRoll(roll){this.setPhysics(roll.physics||{});const start=performance.now();const count=roll.dice.length;
   const allowed=Math.max(1,this.maxVisible);const selected=roll.dice.slice(-allowed);for(let i=0;i<selected.length;i++){
     const die=selected[i],geom=GEOMS[die.sides]||GEOMS[20],index=((die.faceIndex%geom.faces.length)+geom.faces.length)%geom.faces.length;
     const target=[0,.24,1];const end=Q.mul(Q.axis(target,(Math.random()-.5)*.32),Q.to(geom.faces[index].normal,target));
     const startQuat=Q.mul(Q.axis(V.unit([Math.random(),Math.random(),Math.random()]),Math.random()*TAU),end);
     this.dice.push({id:roll.id+'-'+i,sides:die.sides,percentile:die.percentile,label:die.label,faceIndex:index,style:die.style||this.style,name:roll.name,rollId:roll.id,start,startQuat,end,axis:V.unit([Math.random()-.5,Math.random()-.5,Math.random()-.5]),seed:Math.random()*100,duration:roll.physics?.duration||2900,physics:roll.physics||this.physics,settled:false});
   }
   this.dice=this.dice.slice(-allowed);
 }
 loop(now){if(!this.active)return;this.resize();const ctx=this.ctx,{w,h}=this;ctx.clearRect(0,0,w,h);this.drawDecor(ctx,w,h,now);
   if(this.preview) this.drawPreview(ctx,w,h,now);
   else this.drawBoard(ctx,w,h,now);
   this.raf=requestAnimationFrame(this.loop);
 }
 drawDecor(ctx,w,h,now){const cx=w*.5,cy=h*.53,r=Math.min(w*.31,h*.48);const grd=ctx.createRadialGradient(cx,cy,5,cx,cy,Math.max(w,h)*.62);grd.addColorStop(0,'rgba(158,112,237,.075)');grd.addColorStop(.52,'rgba(150,95,215,.022)');grd.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=grd;ctx.fillRect(0,0,w,h);drawRune(ctx,cx,cy,r,'#b493df',.95);drawRune(ctx,cx,cy,r*.64,'#b493df',.65);ctx.save();ctx.strokeStyle='rgba(229,181,105,.09)';for(let n=0;n<8;n++){const a=n*TAU/8+PI/8;ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*r*.72,cy+Math.sin(a)*r*.72);ctx.lineTo(cx+Math.cos(a)*r*.86,cy+Math.sin(a)*r*.86);ctx.stroke();}ctx.restore();
   // Subtle stars / embers.
   for(let i=0;i<29;i++){const x=((i*137.5+43)%997)/997*w,y=((i*267.3+79)%991)/991*h;const a=.08+.12*(.5+.5*Math.sin(now*.0005+i*4));ctx.fillStyle=`rgba(230,207,165,${a})`;ctx.fillRect(x,y,i%7===0?1.9:1.1,i%7===0?1.9:1.1);}
 }
 drawPreview(ctx,w,h,now){const sides=this.previewSides,rot=Q.mul(Q.axis([.15,1,.05],(now-this.idleTime)*.00038),Q.axis([1,0,0],-.18));let size=Math.min(w,h)*.36;size=clamp(size,60,185);this.drawDie(ctx,{x:w/2,y:h*.51,r:size,quat:rot,sides,style:this.style,faceIndex:-1,label:null,shadow:0,opacity:1},now);}
 drawBoard(ctx,w,h,now){if(!this.dice.length){let q=Q.mul(Q.axis([0,1,0],(now-this.idleTime)*.00018),Q.axis([1,.2,0],-.1));this.drawDie(ctx,{x:w*.51,y:h*.51,r:Math.min(w,h)*.185,quat:q,sides:20,style:{base:'#241c3a',edge:'#54476e',ink:'#6e6380',glow:'#614781',metalness:.4},faceIndex:-1,shadow:0,opacity:.5},now);return;}
   const n=this.dice.length,cols=Math.max(1,Math.ceil(Math.sqrt(n*w/Math.max(1,h)*.95))),rows=Math.ceil(n/cols),usableW=w*.85,usableH=h*.70;
   const size=clamp(Math.min(usableW/Math.max(cols,1),usableH/Math.max(rows,1))*.36,19,Math.min(w,h)*.19);
   for(let i=0;i<n;i++){
     const d=this.dice[i],col=i%cols,row=Math.floor(i/cols),colCount=Math.min(cols,n-row*cols),x=w*.5+((col-(colCount-1)/2)*usableW/cols),baseY=h*.53+(row-(rows-1)/2)*(usableH/rows);
     const t=clamp((now-d.start)/d.duration,0,1),p=d.physics,old=d.start+(d.duration*.92);
     const gravity=clamp(Number(p.gravity)||17,2,32),bounce=clamp(Number(p.bounce)||.43,.02,.98),friction=clamp(Number(p.friction)||.31,.01,1),force=clamp(Number(p.force)||8,2,17),spin=clamp(Number(p.spin)||10,1,25);
     const phase=t<.75?t/.75:1;
     const envelope=Math.pow(1-phase,1.18);
     const arcs=Math.sin(Math.PI*(1+gravity/30)*phase*3.1);
     const rise= t<.75 ? Math.abs(arcs)*size*(.8+force*.15)*envelope*(.6+bounce) + (1-phase)*size*(force/9) : 0;
     const drift=Math.sin(d.seed+t*5.3)*(1-t)*(force*1.25)*(1.05-friction*.7);
     let q;
     if(t<.71){let angle=(t/.71)*PI*(2+spin*.42)*(1-friction*.17);q=Q.mul(Q.axis(d.axis,angle),d.startQuat);}else{const mid=Q.mul(Q.axis(d.axis,PI*(2+spin*.42)*(1-friction*.17)),d.startQuat);q=Q.slerp(mid,d.end,smooth(clamp((t-.71)/.29,0,1)));}
     const lift=t>=.75? 0:rise;
     this.drawDie(ctx,{x:x+drift,y:baseY-lift,r:size*(d.sides===4?1.12:1),quat:q,sides:d.sides,style:d.style,label:d.label,percentile:d.percentile,faceIndex:d.faceIndex,shadow:Math.min(1,Math.max(0,lift/(size*3))),opacity:1},now);
   }
 }
 drawDie(ctx,opt){const {x,y,r,quat,sides,style,shadow=0,opacity=1}=opt,geom=GEOMS[sides]||GEOMS[20];if(!geom)return;ctx.save();ctx.globalAlpha=opacity;
   const floorY=y+Math.min(r*.88,shadow*r*.9);ctx.save();ctx.translate(x,floorY+r*.90);ctx.scale(1,.24);const g=ctx.createRadialGradient(0,0,2,0,0,r*1.35);g.addColorStop(0,`rgba(4,2,14,${.39*(1-shadow*.6)})`);g.addColorStop(1,'rgba(4,2,14,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,r*1.35,0,TAU);ctx.fill();ctx.restore();
   const verts=geom.vertices.map(v=>Q.rot(quat,v));const transformed=geom.faces.map((f,index)=>{const points=f.indices.map(i=>{const a=verts[i],pers=2.85/(2.85-a[2]*.22);return [x+a[0]*r*pers,y-a[1]*r*pers,a[2]];});const normal=Q.rot(quat,f.normal),center=Q.rot(quat,f.center);return {points,normal,center,index,depth:center[2]};}).filter(f=>f.normal[2]>.02).sort((a,b)=>a.depth-b.depth);
   const base=style.base||'#2d2450',edge=style.edge||'#e8b96b',ink=style.ink||'#fff4d8',glow=style.glow||'#a783ef',metal=clamp(style.metalness??.5,0,1);
   ctx.shadowColor=rgba(glow,.35);ctx.shadowBlur=r*.22;
   for(const f of transformed){const light=V.unit([-.65,.9,1.6]),dot=clamp(V.dot(f.normal,light),0,1),lightness=.49+dot*.56+metal*.14;const points=f.points;
     shape(ctx,points);ctx.fillStyle=tint(base,lightness);ctx.fill();ctx.shadowBlur=0;ctx.lineJoin='round';ctx.strokeStyle=rgba(edge,.63+dot*.32);ctx.lineWidth=clamp(r*.019,.7,2.8);ctx.stroke();
     const cx=points.reduce((a,p)=>a+p[0],0)/points.length,cy=points.reduce((a,p)=>a+p[1],0)/points.length;
     ctx.save();shape(ctx,points);ctx.clip();const gr=ctx.createRadialGradient(cx-r*.14,cy-r*.19,1,cx,cy,r*.9);gr.addColorStop(0,`rgba(255,255,255,${.075+dot*.085})`);gr.addColorStop(1,'rgba(0,0,0,.22)');ctx.fillStyle=gr;ctx.fillRect(x-r*1.3,y-r*1.3,r*2.6,r*2.6);
     if(f.points.length>=4){ctx.strokeStyle=rgba(edge,.2);ctx.lineWidth=.7;ctx.beginPath();for(const p of f.points){ctx.moveTo(cx,cy);ctx.lineTo(p[0],p[1]);}ctx.stroke();}
     const innerRadius=Math.min(...points.map(p=>Math.hypot(p[0]-cx,p[1]-cy)));const label=sides===10&&opt.percentile!==undefined?(String(opt.label).length===2?String(f.index*10).padStart(2,'0'):String(f.index)):String(f.index+1);
     const fs=clamp(innerRadius*(label.length===2?.75:.95),9,r*.46);
     if(f.normal[2]>.1&&innerRadius>6){ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=textFont(fs);ctx.shadowColor='rgba(0,0,0,.75)';ctx.shadowBlur=3;ctx.fillStyle=ink;ctx.fillText(label,cx,cy+fs*.04);ctx.shadowBlur=0;
       // A tiny gilded marker helps distinguish 6/9.
       if(label==='6'||label==='9'){ctx.strokeStyle=rgba(ink,.8);ctx.lineWidth=Math.max(.8,fs*.06);ctx.beginPath();ctx.moveTo(cx-fs*.24,cy+fs*.44);ctx.lineTo(cx+fs*.24,cy+fs*.44);ctx.stroke();}}
     ctx.restore();ctx.shadowColor=rgba(glow,.12);ctx.shadowBlur=r*.07;
   }
   ctx.restore();
 }
 destroy(){this.active=false;cancelAnimationFrame(this.raf);}
}
window.SerrenyaDiceEngine={DiceStage,faceCounts:Object.fromEntries(Object.entries(GEOMS).map(([n,g])=>[n,g.faces.length]))};
})();
