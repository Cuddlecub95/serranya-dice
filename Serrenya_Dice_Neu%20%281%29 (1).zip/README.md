# ✦ Serrenya Dice – Der magische Würfeltisch

**Fertige, sofort ausführbare Web-App** für gemeinsame D&D-Würfe. Ein grosser Monitor zeigt animierte 3D-Würfel; alle Spielenden verbinden ihr Smartphone mit dem sechsstelligen Raumcode und würfeln live.

## 1. So startest du die App am PC (Windows)

1. Lade die ZIP-Datei herunter und entpacke sie vollständig.
2. Falls nicht vorhanden: Installiere **Node.js 20 oder neuer** von https://nodejs.org/.
3. Doppelklicke auf **`STARTEN-Windows.bat`**. Alternativ öffne im entpackten Ordner ein Terminal und starte `node server.js`.
4. Öffne **http://localhost:3000** im Browser. Klicke auf **„Neuen Raum erstellen“**.
5. Mitspielende auf einem anderen Gerät benötigen einen öffentlich erreichbaren Link oder die IP-Adresse des Computers im selben WLAN; siehe Abschnitt 2 oder 3.

**Wichtig:** Das Hauptdisplay muss geöffnet bleiben, damit ihr die Animationen seht. Die Würfe werden unabhängig davon serverseitig ausgewürfelt.

## 2. Öffentlich im Internet veröffentlichen (Render)

Für den einfachsten gemeinsamen Zugriff von beliebigen Orten kannst du diese App als Node.js-Webservice veröffentlichen. **Sie ist bereits deploy-fertig** (`render.yaml`, `Dockerfile`, kein Installieren von Programm-Bibliotheken nötig).

1. Erstelle ein GitHub-Konto auf https://github.com/ und lege ein neues Repository an, z. B. `serrenya-dice`.
2. Lade die **Inhalte des entpackten App-Ordners** ins Repository hoch. Wichtig: `server.js`, `package.json`, `public/` und `render.yaml` müssen im Repository-Hauptverzeichnis liegen.
3. Erstelle auf https://dashboard.render.com/ unter **New → Web Service** einen Dienst und verbinde dein GitHub-Repository. Wähle **Node**.
4. Verwende als **Build Command** `echo ready` und als **Start Command** `node server.js`. Wähle, falls verfügbar, den kostenlosen **Free**-Plan und starte die Bereitstellung.
5. Render zeigt dir danach deine eigene HTTPS-Adresse im Format `https://dein-projekt.onrender.com`. **Diese Adresse ist die App.** Öffne sie auf dem Hauptdisplay; alle Spielenden können per Raumcode, Link oder QR-Code beitreten.

Die offizielle Render-Anleitung findest du unter https://render.com/docs/your-first-deploy.

**Hinweis zum kostenlosen Betrieb:** Kostenlose Render-Webservices können bei Inaktivität pausieren; Neustarts können die noch nicht dauerhaft gespeicherten Räume und Wurfhistorien löschen. Für längere, verlässlich verfügbare Kampagnen kann ein dauerhaft aktiver Hosting-Tarif sinnvoll sein. Diese App speichert die Räume vorerst nur im Arbeitsspeicher und enthält keine Datenbank. Sie startet nach Server-Neustart mit leeren Räumen.

## 3. Im selben WLAN spielen (ohne Hosting)

Starte die App wie oben am PC. Ermittle die lokale IP-Adresse des PCs, z. B. in Windows mit `ipconfig` (IPv4-Adresse). Öffne dann auf den Smartphones, die im selben WLAN sind, eine Adresse nach diesem Muster:

`http://192.168.1.10:3000`  ← Beispiel; IP durch die **tatsächliche** PC-Adresse ersetzen.

Lässt sich die Seite nicht öffnen, prüfe, ob beide Geräte im selben WLAN sind und ob die Firewall des Computers eingehende Verbindungen auf Port **3000/TCP** erlaubt. Der QR-Code verwendet immer die Adresse, unter der du die App am Hauptdisplay aufgerufen hast: Öffne den Tisch deshalb auf dem PC für WLAN-Partys über die lokale IP-Adresse und nicht über `localhost`.

## App-Funktionen

- Würfeltypen: **W4, W6, W8, W10, W12, W20 und W100** (W100 als zwei W10).
- Pro Wurf **1 bis 8 Würfel**; Hauptdisplay zeigt **1 bis 24** gleichzeitig an (einstellbar).
- **3D-Würfelkörper** für jede Würfelform; animierte Rotation, Flug und Abprallen.
- Physik-Einstellungen: **Schwerkraft, Sprungkraft, Reibung, Wurfkraft, Rotation und Animationsdauer**.
- Eigener Würfel je Smartphone, inklusive **sechs Designvorlagen**, vier editierbaren Farben und Metallglanz-Regler.
- **Live-Mehrspielermodus** über WebSockets; bis zu **40 Geräte pro Raum**.
- Raumcode, Link und optionaler externer QR-Code (für QR-Bildgenerierung wird `api.qrserver.com` geladen; bei dessen Nichtverfügbarkeit funktioniert die Eingabe des Raumcodes weiterhin).
- Verlauf der letzten Würfe; Hauptdisplay kann diesen Verlauf löschen.
- Responsive Oberfläche für Smartphone, Tablet, Notebook, Monitor und Fernseher.
- Kein Login notwendig, kein Account für Spielende, keine Werbung, keine npm-Abhängigkeiten.

### Zufall und Fairness

**Jedes Würfelergebnis wird vor der Animation auf dem Server bestimmt.** Dafür verwendet der Server `crypto.randomInt()` (kryptografischer Zufallszahlengenerator mit unverzerrter Ganzzahlverteilung). Bei einem W20 haben alle Ergebnisse von 1 bis 20 genau die gleiche Wahrscheinlichkeit. Die visuellen Physikregler beeinflussen lediglich den Ablauf der Animation, **niemals das Ergebnis**. Ein W100 liefert Werte 1–100 inklusive; der Wert 100 wird als `00 + 0` gezeigt.

### Sicherheit und Einschränkungen

- Raumcodes sind öffentlich teilbare Beitrittscodes; sie sind **keine privaten Passwörter**. Gib den Beitrittslink nur den Personen, mit denen du spielen möchtest.
- Nur das Hauptdisplay besitzt den geheimen Administrations-Token. Er wird auf dem Hauptgerät in der Session-Storage des Browsers gespeichert, nicht mit Spielenden geteilt.
- Spielende können nur erlaubte Würfelanforderungen (Würfeltyp, Anzahl, Design) senden und **keine Ergebnisse vorgeben**.
- Es werden keine IP-Adressen oder Würfelergebnisse dauerhaft in einer Datenbank gespeichert. Räume verschwinden nach längerer Inaktivität oder einem Neustart des Servers.
- Die Physik ist eine anpassbare, plausible **3D-Wurfanimation**, keine vollständige starre-Körper-Simulation mit geometrisch exakter Kollisionsauflösung. Die Würfelfläche zeigt das serverseitig vorab gezogene Ergebnis.

## Technische Details

- Node.js >=20, native HTTP- und WebSocket-Implementierung, ohne `npm install`.
- Eigenständiger Canvas-3D-Renderer, mathematisch konstruierte reguläre Polyeder und W10-Trapezoeder; keine externen Render-Bibliotheken.
- Prüfungen ausführen: `npm test` (Node-Bordmittel).
- `PORT`-Umgebungsvariable für Hosting möglich, Standard `3000`.

---

*Serrenya Dice · Ein eigenständiger App-Prototyp für deine Spielrunde. Es gibt derzeit keine Cloud-Datenbank, keine Push-Benachrichtigungen und keine native iOS-/Android-App aus einem App Store. Die mobile Web-App wird direkt im Smartphone-Browser verwendet.*


## Version 2.0 — Die Taverne zum Goldenen Wurf

Alle bisherigen Würfeltypen und Multiplayer-Funktionen bleiben erhalten. Neu sind die Tavernenkulisse, überarbeitetes Facetten-Rendering, materialabhängige Texturen und Lichtreflexe, natürlichere Wurfbewegung, zehn Designvorlagen und umfangreiche individuelle Einstellungen. Die Grafikqualität kann auf Ultra, Hoch, Automatisch oder Energiesparen gesetzt werden. Die Berechnung der geworfenen Augenzahlen findet ausschliesslich auf dem Server statt.

Falls du im bestehenden GitHub-Repository nur eine ZIP-Datei gespeichert hast, siehe `UPDATE-ONLINE.md` für die Aktualisierung des Render-Deployments.
