/* Serrenya Dice — self-contained 3D polyhedron renderer and configurable throw animation.
   Uses HTML Canvas 2D, real 3D coordinates/quaternions, no external dependencies. */
(() => {
'use strict';
const PI = Math.PI, TAU = PI*2, PHI=(1+Math.sqrt(5))/2;
const V={add:(a,b)=>a.map((x,i)=>x+b[i]),sub:(a,b)=>a.map((x,i)=>x-b[i]), mul:(a,s)=>a.map(x=>x*s),dot:(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0), cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm:a=>Math.hypot(...a),unit:a=>{const m=Math.hypot(...a)||1;return a.map(x=>x/m);}};
const Q={mul:(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]],axis:(a,r)=>{const n=V.unit(a),s=Math.sin(r/2);return [...V.mul(n,s),Math.cos(r/2)];},rot:(q,p)=>{const u=q.slice(0,3),s=q[3];return V.add(V.add(V.mul(u,2*V.dot(u,p)),V.mul(p,s*s-V.dot(u,u))),V.mul(V.cross(u,p),2*s));},to:(a,b)=>{const x=V.unit(a),y=V.unit(b),d=V.dot(x,y);if(d<-.999999)return Q.axis(V.unit(V.cross(x,Math.abs(x[0])<.8?[1,0,0]:[0,1,0])),PI);const c=V.cross(x,y);return V.unit([...c,1+d]);},slerp:(a,b,t)=>{let dot=a.reduce((v,x,i)=>v+x*b[i],0);if(dot<0){b=b.map(v=>-v);dot=-dot;}if(dot>.9995)return V.unit(a.map((v,i)=>v*(1-t)+b[i]*t));const th=Math.acos(Math.max(-1,Math.min(1,dot))),s=Math.sin(th);return a.map((v,i)=>(v*Math.sin((1-t)*th)+b[i]*Math.sin(t*th))/s);}};
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
const smooth=t=>t*t*(3-2*t);
function hull(vertices){
  const normVerts=vertices.map(v=>V.mul(v,1/Math.max(...vertices.map(V.norm))));
  const planes=[];
  for(let i=0;i<normVerts.length;i++)for(let j=i+1;j<normVerts.length;j++)for(let k=j+1;k<normVerts.length;k++){
    let n=V.cross(V.sub(normVerts[j],normVerts[i]),V.sub(normVerts[k],normVerts[i]));if(V.norm(n)<1e-5)continue;n=V.unit(n);let above=0,below=0;for(const p of normVerts){const side=V.dot(n,V.sub(p,normVerts[i]));if(side>1e-5)above++;if(side< -1e-5)below++;if(above&&below)break;}
    if(above&&below)continue;if(above)n=V.mul(n,-1);
    const distance=V.dot(n,normVerts[i]);if(planes.some(p=>V.dot(p.normal,n)>.9999&&Math.abs(p.distance-distance)<1e-4))continue;
    planes.push({normal:n,distance});
  }
  const faces=planes.map(p=>{
    const indices=normVerts.map((v,i)=>({v,i})).filter(o=>Math.abs(V.dot(p.normal,o.v)-p.distance)<1e-4).map(o=>o.i);
    const center=V.mul(indices.reduce((s,i)=>V.add(s,normVerts[i]),[0,0,0]),1/indices.length);
    const xaxis=V.unit(V.sub(normVerts[indices[0]],center)),yaxis=V.cross(p.normal,xaxis);
    indices.sort((a,b)=>Math.atan2(V.dot(V.sub(normVerts[a],center),yaxis),V.dot(V.sub(normVerts[a],center),xaxis))-Math.atan2(V.dot(V.sub(normVerts[b],center),yaxis),V.dot(V.sub(normVerts[b],center),xaxis)));
    return {indices,center,normal:p.normal};
  }).filter(f=>f.indices.length>=3);
  return {vertices:normVerts,faces};
}
function makeGeometry(sides){
  let v=[];
  if(sides===4) v=[[1,1,1],[-1,-1,1],[-1,1,-1],[1,-1,-1]];
  else if(sides===6)for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1])v.push([x,y,z]);
  else if(sides===8) v=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  else if(sides===20){for(const a of [-1,1])for(const b of [-1,1])v.push([0,a,b*PHI],[a,b*PHI,0],[a*PHI,0,b]);}
  else if(sides===12){for(const a of [-1,1])for(const b of [-1,1])for(const c of [-1,1])v.push([a,b,c]);for(const a of [-1,1])for(const b of [-1,1])v.push([0,a/PHI,b*PHI],[a/PHI,b*PHI,0],[a*PHI,0,b/PHI]);}
  else if(sides===10){const top=1.4,ring=top*(1-Math.cos(PI/5))/(1+Math.cos(PI/5));v.push([0,0,top],[0,0,-top]);for(let i=0;i<5;i++){const a=TAU*i/5;v.push([Math.cos(a),Math.sin(a),ring]);v.push([Math.cos(a+PI/5),Math.sin(a+PI/5),-ring]);}}
  const geometry=hull(v);
  // Sort face ordering in a deterministic way so faceIndex selected server-side is stable.
  geometry.faces.sort((a,b)=>b.normal[2]-a.normal[2]||b.normal[1]-a.normal[1]||a.normal[0]-b.normal[0]);
  return geometry;
}
const GEOMS=Object.fromEntries([4,6,8,10,12,20].map(n=>[n,makeGeometry(n)]));
function hex(color){const x=/^#[a-f0-9]{6}$/i.test(color||'')?color:'#342355';return [parseInt(x.slice(1,3),16),parseInt(x.slice(3,5),16),parseInt(x.slice(5,7),16)];}
function tint(color,l){const c=hex(color);return `rgb(${c.map(v=>Math.round(clamp(v*l,0,255))).join(',')})`;}
function rgba(color,opacity){const c=hex(color);return `rgba(${c.join(',')},${opacity})`;}
function textFont(px){return `700 ${Math.round(px)}px Georgia, 'Times New Roman', serif`;}
function shape(ctx,pts){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);ctx.closePath();}
function drawRune(ctx,x,y,r,color,alpha=1){ctx.save();ctx.strokeStyle=rgba(color,.22*alpha);ctx.lineWidth=1;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.stroke();ctx.beginPath();ctx.arc(x,y,r*.83,0,TAU);ctx.stroke();for(let k=0;k<12;k++){const t=k*TAU/12;ctx.beginPath();ctx.moveTo(x+Math.cos(t)*r*.88,y+Math.sin(t)*r*.88);ctx.lineTo(x+Math.cos(t)*r*.96,y+Math.sin(t)*r*.96);ctx.stroke();}ctx.restore();}
// Quality is limited by pixel budget so Ultra remains usable even on 4K displays.
let RENDER_QUALITY='auto';
const QUALITY_DPR={economy:1,high:1.7,ultra:2.8};
const mix=(a,b,t)=>a+(b-a)*t;
const easeOut=t=>1-Math.pow(1-t,3);
const fract=v=>v-Math.floor(v);
const hash=(a,b=0)=>fract(Math.sin(a*127.1+b*311.7)*43758.5453);
function roundedRect(ctx,x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
function drawShine(ctx,points,cx,cy,r,amount){
 const grad=ctx.createLinearGradient(cx-r*.52,cy-r*.57,cx+r*.72,cy+r*.8);
 grad.addColorStop(0,`rgba(255,248,222,${.14+amount*.18})`);
 grad.addColorStop(.3,`rgba(255,255,255,${.04+amount*.08})`);
 grad.addColorStop(.58,`rgba(15,6,20,${.04+amount*.13})`);
 grad.addColorStop(1,`rgba(255,224,170,${amount*.10})`);
 ctx.fillStyle=grad;shape(ctx,points);ctx.fill();
}
function drawGlyph(ctx,text,cx,cy,size,style,light){
 const ink=style.ink||'#fff5dc',mode=style.numerals||'ancient';
 const family=mode==='modern'?'Arial, sans-serif':mode==='classic'?"Georgia,serif":"Palatino, 'Book Antiqua', Georgia, serif";
 ctx.save();ctx.translate(cx,cy);ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`${mode==='modern'?800:700} ${Math.round(size)}px ${family}`;
 ctx.lineWidth=Math.max(.75,size*.1);ctx.lineJoin='round';
 // Deep inset engraving, then a thin reflective ink layer.
 ctx.strokeStyle='rgba(11,7,9,.7)';ctx.strokeText(text,0,size*.025);
 ctx.fillStyle='rgba(5,4,5,.55)';ctx.fillText(text,0,size*.09);
 ctx.shadowColor=rgba(style.glow||'#b18bff',.14+(style.aura||0)*.28);ctx.shadowBlur=size*.2;
 ctx.fillStyle=ink;ctx.fillText(text,0,-size*.02);
 ctx.shadowBlur=0;ctx.fillStyle=`rgba(255,255,255,${.11+light*.16})`;ctx.fillText(text,-size*.018,-size*.08);
 if(text==='6'||text==='9'){
    ctx.beginPath();ctx.moveTo(-size*.26,size*.50);ctx.lineTo(size*.26,size*.50);ctx.lineWidth=Math.max(1,size*.05);ctx.strokeStyle=ink;ctx.stroke();
 }
 ctx.restore();
}
function drawPattern(ctx,opt){
 const {pattern,material,grain,points,cx,cy,r,index,edge}=opt;
 const intensity=grain??.25,diameter=Math.max(5,Math.hypot(...V.sub(points[0],points[1])));
 const alpha=.09+intensity*.22;
 if(material==='stone'||material==='bone'){
  for(let k=0;k<32;k++){
   const xx=cx+(hash(index*61+k,8)-.5)*diameter*1.8, yy=cy+(hash(index*17+k,5)-.5)*diameter*1.8;
   const v=hash(index*31+k,3);ctx.fillStyle=v>.5?`rgba(255,244,218,${alpha*.65})`:`rgba(10,5,3,${alpha*.65})`;
   ctx.fillRect(xx,yy,.6+v*1.6,.6+v*.8);
  }
 }
 if(material==='wood'){
  for(let i=-8;i<=8;i++){
    ctx.beginPath();ctx.strokeStyle=`rgba(38,20,10,${.025+intensity*.12})`;
    ctx.lineWidth=.65+hash(i,index)*.8;
    let yy=cy+i*r*.065;
    ctx.moveTo(cx-r,yy);ctx.bezierCurveTo(cx-r*.22,yy+Math.sin(i*3)*r*.13,cx+r*.18,yy-Math.cos(i*3)*r*.08,cx+r,yy);ctx.stroke();
  }
 }
 if(material==='metal'){
   for(let i=-12;i<12;i++){let yy=cy+i*r*.065;ctx.beginPath();ctx.moveTo(cx-r,yy);ctx.lineTo(cx+r,yy-r*.2);ctx.strokeStyle=`rgba(255,250,225,${.018+intensity*.035})`;ctx.lineWidth=.6;ctx.stroke();}
 }
 if(pattern==='runes'){
   const symbols=['ᚨ','ᛃ','ᛟ','ᚹ','ᚷ','ᛉ','ᚱ','ᚾ'];ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`${Math.max(7,r*.09)}px Georgia,serif`;ctx.fillStyle=rgba(edge,.29);const rr=r*.57;
   for(let i=0;i<6;i++){const a=i*TAU/6+PI/6;ctx.fillText(symbols[(i+index)%symbols.length],cx+Math.cos(a)*rr,cy+Math.sin(a)*rr);}ctx.restore();
 }else if(pattern==='stars'){
   for(let i=0;i<14;i++){const a=hash(i,index+3)*TAU,rr=Math.sqrt(hash(index*53,i))*r*.9,x=cx+Math.cos(a)*rr,y=cy+Math.sin(a)*rr;
     ctx.fillStyle=rgba(edge,.25+hash(i,index)*.25);ctx.fillRect(x,y,hash(i+10,index)>.75?2:1,1.1);}
 }else if(pattern==='veins'){
    for(let i=0;i<4;i++){const y=cy+(i-1.5)*r*.23;ctx.beginPath();ctx.moveTo(cx-r,y-r*.2);ctx.bezierCurveTo(cx-r*.28,y+r*.18,cx+r*.24,y-r*.2,cx+r,y+r*.11);ctx.strokeStyle=rgba(edge,.12+intensity*.18);ctx.lineWidth=i%2?1:.7;ctx.stroke();}
 }else if(pattern==='carved'){
   for(let i=0;i<6;i++){const a=i*TAU/6;ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*r*.57,cy+Math.sin(a)*r*.57);ctx.lineTo(cx+Math.cos(a+.4)*r*.66,cy+Math.sin(a+.4)*r*.66);ctx.strokeStyle=rgba(edge,.28);ctx.lineWidth=1;ctx.stroke();}
 }else if(pattern==='scales'){
   for(let row=-4;row<5;row++)for(let col=-3;col<4;col++){const xx=cx+(col+(row%2)*.5)*r*.21,yy=cy+row*r*.18;ctx.beginPath();ctx.arc(xx,yy,r*.14,0,PI);ctx.strokeStyle=rgba(edge,.13);ctx.lineWidth=.8;ctx.stroke();}
 }
}
class DiceStage {
 constructor(canvas,{preview=false}={}){
  this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:true,desynchronized:false});this.preview=preview;this.dice=[];this.maxVisible=12;
  this.physics={gravity:17,bounce:.43,friction:.31,force:8,spin:10,duration:2900};this.active=true;
  this.style={base:'#2d2450',edge:'#e8b96b',ink:'#fff4d8',glow:'#a783ef',metalness:.52,material:'gem',pattern:'runes',numerals:'ancient',smoothness:.78,aura:.66,bevel:.56,grain:.16,iridescence:.32};
  this.previewSides=20;this.idleTime=performance.now();this.loop=this.loop.bind(this);this.raf=requestAnimationFrame(this.loop);
 }
 resize(){
  const rect=this.canvas.getBoundingClientRect(),w=Math.max(1,Math.round(rect.width)),h=Math.max(1,Math.round(rect.height));
  const ideal=RENDER_QUALITY==='auto'?Math.min(devicePixelRatio||1,2.25):QUALITY_DPR[RENDER_QUALITY]||2;
  const budget=this.preview?2_500_000:7_500_000;
  const dpr=Math.max(.75,Math.min(ideal,Math.sqrt(budget/(w*h)),4096/w,4096/h));
  const cw=Math.round(w*dpr),ch=Math.round(h*dpr);
  if(this.canvas.width!==cw||this.canvas.height!==ch){this.canvas.width=cw;this.canvas.height=ch;}
  this.ctx.setTransform(dpr,0,0,dpr,0,0);this.w=w;this.h=h;
 }
 setPhysics(p){this.physics={...this.physics,...p};this.maxVisible=p.maxVisible??this.maxVisible;this.dice=this.dice.slice(-this.maxVisible);}
 setPreview(sides,style){this.previewSides=sides===100?10:sides;this.style={...this.style,...style};}
 clear(){this.dice=[];}
 addRoll(roll){
  this.setPhysics(roll.physics||{});const start=performance.now(),allowed=Math.max(1,this.maxVisible);
  const selected=roll.dice.slice(-allowed);
  for(let i=0;i<selected.length;i++){
   const die=selected[i],geom=GEOMS[die.sides]||GEOMS[20],index=((die.faceIndex%geom.faces.length)+geom.faces.length)%geom.faces.length;
   const target=V.unit([0,.10,1]),end=Q.to(geom.faces[index].normal,target);
   const seed=Math.random()*100000,startQuat=Q.mul(Q.axis(V.unit([Math.random()-.5,Math.random()-.5,Math.random()-.5]),Math.random()*TAU),end);
   const axis=V.unit([hash(seed,1)-.5,hash(seed,2)-.5,hash(seed,3)-.5]);
   this.dice.push({id:roll.id+'-'+i,sides:die.sides,percentile:die.percentile,label:die.label,faceIndex:index,
    style:{...this.style,...die.style},name:roll.name,rollId:roll.id,start,startQuat,end,axis,seed,
    duration:roll.physics?.duration||2900,physics:roll.physics||this.physics});
  }
  this.dice=this.dice.slice(-allowed);
 }
 loop(now){
  if(!this.active)return;this.resize();const ctx=this.ctx,{w,h}=this;ctx.clearRect(0,0,w,h);
  this.drawDecor(ctx,w,h,now);
  if(this.preview)this.drawPreview(ctx,w,h,now);else this.drawBoard(ctx,w,h,now);
  this.raf=requestAnimationFrame(this.loop);
 }
 drawDecor(ctx,w,h,now){
  // Lit by unseen tavern candles: warm pools of light over a leather dice tray.
  const amber=ctx.createRadialGradient(w*.24,h*.12,1,w*.24,h*.12,Math.max(w,h)*.8);
  amber.addColorStop(0,'rgba(242,168,79,.085)');amber.addColorStop(.48,'rgba(229,140,55,.02)');amber.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=amber;ctx.fillRect(0,0,w,h);
  const mage=ctx.createRadialGradient(w*.72,h*.66,2,w*.72,h*.66,Math.max(w,h)*.44);mage.addColorStop(0,'rgba(117,104,210,.07)');mage.addColorStop(1,'rgba(117,104,210,0)');ctx.fillStyle=mage;ctx.fillRect(0,0,w,h);
  const cx=w*.5,cy=h*.51,rr=Math.min(w*.38,h*.47);
  drawRune(ctx,cx,cy,rr,'#c29857',.65);drawRune(ctx,cx,cy,rr*.74,'#b88d50',.24);
  for(let i=0;i<15;i++){
    const x=hash(i,17)*w,y=hash(i,26)*h,s=1+hash(i,88)*2;
    ctx.globalAlpha=.09+.14*(.5+.5*Math.sin(now*.00046+i*3));ctx.fillStyle='#f2bd6c';ctx.beginPath();ctx.arc(x,y,s*.5,0,TAU);ctx.fill();
  }ctx.globalAlpha=1;
 }
 drawPreview(ctx,w,h,now){
  const angle=(now-this.idleTime)*.00034;
  const rot=Q.mul(Q.axis([.2,1,.06],angle),Q.axis([1,0,.23],-.16));
  const size=clamp(Math.min(w,h)*.38,64,198);
  this.drawDie(ctx,{x:w/2,y:h*.51,r:size,quat:rot,sides:this.previewSides,style:this.style,faceIndex:-1,shadow:.10,lift:size*.13,opacity:1},now);
 }
 drawBoard(ctx,w,h,now){
  if(!this.dice.length){
   const q=Q.mul(Q.axis([.16,1,.03],(now-this.idleTime)*.00017),Q.axis([1,.2,0],-.1));
   this.drawDie(ctx,{x:w*.50,y:h*.52,r:Math.min(w,h)*.20,quat:q,sides:20,style:{base:'#735033',edge:'#b68d53',ink:'#d8bb8d',glow:'#f7c27f',metalness:.39,material:'wood',pattern:'runes',smoothness:.62,aura:.28,bevel:.5,grain:.28},faceIndex:-1,shadow:.13,lift:16,opacity:.84},now);return;
  }
  const n=this.dice.length,cols=Math.max(1,Math.ceil(Math.sqrt(n*w/Math.max(1,h)*.92))),rows=Math.ceil(n/cols);
  const usableW=w*.79,usableH=h*.61;
  const size=clamp(Math.min(usableW/Math.max(cols,1),usableH/Math.max(rows,1))*.39,18,Math.min(w,h)*.21);
  for(let i=0;i<n;i++){
   const d=this.dice[i],col=i%cols,row=Math.floor(i/cols),colCount=Math.min(cols,n-row*cols);
   const centerX=w*.5+(col-(colCount-1)/2)*usableW/cols,centerY=h*.51+(row-(rows-1)/2)*usableH/rows;
   const t=clamp((now-d.start)/d.duration,0,1),p=d.physics;
   const gravity=clamp(Number(p.gravity)||17,2,32),bounce=clamp(Number(p.bounce)||.43,.02,.98),friction=clamp(Number(p.friction)||.31,.01,1),force=clamp(Number(p.force)||8,2,17),spin=clamp(Number(p.spin)||10,1,25);
   const travel=.95+force*.13,drag=.5+friction*1.4;
   // A succession of ballistic arcs with diminishing rebound height.
   let lift=0;
   const boundaries=[0,.28,.51,.68,.8];
   const amplitudes=[1.15,1.0,.52,.20];
   for(let bounceIndex=0;bounceIndex<4;bounceIndex++){
     if(t>=boundaries[bounceIndex]&&t<boundaries[bounceIndex+1]){
       const k=(t-boundaries[bounceIndex])/(boundaries[bounceIndex+1]-boundaries[bounceIndex]);
       lift=Math.sin(k*PI)*size*amplitudes[bounceIndex]*(.67+bounce*.86)*(1.1-gravity*.011)*travel;
       break;
     }
   }
   const throwing=Math.max(0,1-t);
   const offsetX=(hash(d.seed,11)-.5)*size*4.0*Math.pow(throwing,1.5)*travel;
   const offsetY=(hash(d.seed,12)-.5)*size*1.0*Math.pow(throwing,1.7)*travel;
   const wobble=Math.sin((t*15+d.seed)*.94)*size*.27*Math.pow(throwing,1.55)*(1-friction*.5);
   const mx=centerX+offsetX+wobble,my=centerY+offsetY-lift;
   const spinCount=(2.1+spin*.36)*(1-friction*.22);
   const mid=Q.mul(Q.axis(d.axis,TAU*spinCount*.82),d.startQuat);
   let q;
   if(t<.82){const rotation=TAU*spinCount*(1-Math.pow(1-t/.82,2.1))*.82;q=Q.mul(Q.axis(d.axis,rotation),d.startQuat);}
   else{q=Q.slerp(mid,d.end,smooth(clamp((t-.82)/.18,0,1)));}
   this.drawDie(ctx,{x:mx,y:my,r:size*(1+lift/(size*11)),quat:q,sides:d.sides,style:d.style,faceIndex:d.faceIndex,label:d.label,percentile:d.percentile,lift,shadow:clamp(lift/(size*2.8),0,1),opacity:1},now);
  }
 }
 drawDie(ctx,opt,now){
  const {x,y,r,quat,sides,style,shadow=0,lift=0,opacity=1}=opt;
  const geom=GEOMS[sides]||GEOMS[20];if(!geom)return;
  const base=style.base||'#2d2450',edge=style.edge||'#e8b96b',ink=style.ink||'#fff4d8',glow=style.glow||'#a783ef';
  const metal=clamp(style.metalness??.5,0,1),smoothness=clamp(style.smoothness??.70,0,1),aura=clamp(style.aura??.55,0,1),bevel=clamp(style.bevel??.48,0,1),grain=clamp(style.grain??.25,0,1),iridescence=clamp(style.iridescence??.2,0,1);
  ctx.save();ctx.globalAlpha=opacity;
  // Contact shadow grows harder as the die approaches the tabletop.
  ctx.save();ctx.translate(x,y+r*.93+lift*.7);ctx.scale(1,.29+shadow*.06);
  let shadowGrad=ctx.createRadialGradient(0,0,r*.12,0,0,r*1.35);
  shadowGrad.addColorStop(0,`rgba(3,1,1,${.58-shadow*.36})`);shadowGrad.addColorStop(.52,`rgba(5,2,0,${.25-shadow*.12})`);shadowGrad.addColorStop(1,'rgba(4,1,0,0)');
  ctx.fillStyle=shadowGrad;ctx.beginPath();ctx.arc(0,0,r*1.35,0,TAU);ctx.fill();ctx.restore();
  // The geometry is a true regular polyhedron, lit with three independent light contributions.
  const verts=geom.vertices.map(v=>Q.rot(quat,v));
  const transformed=geom.faces.map((f,index)=>{
   const points=f.indices.map(i=>{const a=verts[i],pers=3.6/(3.6-a[2]*.34);return [x+a[0]*r*pers,y-a[1]*r*pers,a[2]];});
   const normal=Q.rot(quat,f.normal),center=Q.rot(quat,f.center);return {points,normal,center,index,depth:center[2]};
  }).filter(f=>f.normal[2]>.005).sort((a,b)=>a.depth-b.depth);
  if(aura>.18){ctx.save();ctx.shadowColor=rgba(glow,.38*aura);ctx.shadowBlur=r*(.07+aura*.3);ctx.fillStyle=rgba(glow,.02*aura);ctx.beginPath();ctx.arc(x,y,r*.74,0,TAU);ctx.fill();ctx.restore();}
  const key=V.unit([-.57,.78,1.65]),rim=V.unit([.7,-.15,.8]);
  for(const f of transformed){
   const dot=clamp(V.dot(f.normal,key),0,1),rimDot=clamp(V.dot(f.normal,rim),0,1);
   const lightness=.48+dot*.43+rimDot*.11+metal*.08;
   const pts=f.points;
   const cx=pts.reduce((a,p)=>a+p[0],0)/pts.length,cy=pts.reduce((a,p)=>a+p[1],0)/pts.length;
   const innerRadius=Math.min(...pts.map(p=>Math.hypot(p[0]-cx,p[1]-cy)));
   // Real material shading: base pigmentation, subtle ambient occlusion and specular spots.
   shape(ctx,pts);ctx.fillStyle=tint(base,lightness);ctx.fill();
   ctx.save();shape(ctx,pts);ctx.clip();
   const gradient=ctx.createLinearGradient(cx-r*.8,cy-r*.78,cx+r*.7,cy+r*.65);
   gradient.addColorStop(0,`rgba(255,241,200,${.10+smoothness*.12+dot*.15})`);
   gradient.addColorStop(.27,`rgba(255,248,225,${.03+metal*.06})`);
   gradient.addColorStop(.65,`rgba(0,0,0,${.1+grain*.13})`);
   gradient.addColorStop(1,`rgba(0,0,0,${.23+grain*.15})`);
   ctx.fillStyle=gradient;ctx.fillRect(x-r*1.5,y-r*1.5,r*3,r*3);
   if(style.material==='crystal'){
     const refract=ctx.createLinearGradient(cx-r*.63,cy-r*.65,cx+r*.6,cy+r*.8);
     refract.addColorStop(0,rgba('#ffffff',.15+iridescence*.16));
     refract.addColorStop(.4,rgba(glow,.13));
     refract.addColorStop(.68,rgba('#ffffff',.02));
     refract.addColorStop(1,rgba(edge,.21));
     ctx.fillStyle=refract;ctx.fillRect(x-r*1.5,y-r*1.5,r*3,r*3);
   }else if(style.material==='bone'){
     const antique=ctx.createRadialGradient(cx-r*.2,cy-r*.3,3,cx,cy,r);
     antique.addColorStop(0,'rgba(255,247,211,.17)');antique.addColorStop(1,'rgba(100,61,22,.23)');
     ctx.fillStyle=antique;ctx.fillRect(x-r*1.5,y-r*1.5,r*3,r*3);
   }else if(style.material==='gem'){
     ctx.fillStyle=rgba(glow,.08+iridescence*.11);
     ctx.beginPath();ctx.moveTo(cx-r*.6,cy-r*.6);ctx.lineTo(cx+r*.48,cy-r*.12);ctx.lineTo(cx-r*.12,cy+r*.5);ctx.closePath();ctx.fill();
   }
   if(smoothness>.24)drawShine(ctx,pts,cx,cy,r,smoothness*(.5+dot*.5));
   if(iridescence>.02){const sh=ctx.createRadialGradient(cx+r*.36,cy-r*.38,1,cx,cy,r);
     sh.addColorStop(0,rgba(glow,.17*iridescence));sh.addColorStop(.65,rgba(edge,.07*iridescence));sh.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=sh;ctx.fillRect(x-r,y-r,r*2,r*2);
   }
   drawPattern(ctx,{pattern:style.pattern||'none',material:style.material||'gem',grain,points:pts,cx,cy,r,index:f.index,edge});
   // Polished bevel: individual inner face rim and narrow surface highlight.
   const shrink=.04+bevel*.12;
   const inner=pts.map(p=>[mix(p[0],cx,shrink),mix(p[1],cy,shrink)]);
   shape(ctx,inner);ctx.strokeStyle=rgba(edge,.23+bevel*.21);ctx.lineWidth=Math.max(.7,r*.005);ctx.stroke();
   const label=sides===10&&opt.percentile!==undefined?(String(opt.label).length===2?String(f.index*10).padStart(2,'0'):String(f.index)):String(f.index+1);
   const fs=clamp(innerRadius*(label.length===2?.68:.93),8,r*.49);
   if(f.normal[2]>.065&&innerRadius>6){drawGlyph(ctx,label,cx,cy+fs*.015,fs,{ink,glow,aura,numerals:style.numerals},dot);}
   ctx.restore();
   // Distinct metallic facet rim, very thin secondary glint along lit edges.
   ctx.lineJoin='round';shape(ctx,pts);ctx.strokeStyle=tint(edge,.49+dot*.48+metal*.13);ctx.lineWidth=clamp(r*(.016+bevel*.013),.85,5.3);ctx.stroke();
   if(dot>.25){ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);ctx.lineTo(pts[1][0],pts[1][1]);ctx.strokeStyle=`rgba(255,248,210,${(.11+dot*.32)*(metal*.4+.6)})`;ctx.lineWidth=Math.max(.7,r*.011);ctx.stroke();}
  }
  ctx.restore();
 }
 destroy(){this.active=false;cancelAnimationFrame(this.raf);}
}
window.SerrenyaDiceEngine={DiceStage,setQuality(v){RENDER_QUALITY=['auto','high','ultra','economy'].includes(v)?v:'auto';},faceCounts:Object.fromEntries(Object.entries(GEOMS).map(([n,g])=>[n,g.faces.length]))};
})();
