@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Serrenya Dice - Server
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js ist noch nicht installiert.
  echo Installiere Node.js 20 oder neuer von https://nodejs.org/
  echo Starte danach diese Datei erneut.
  echo.
  pause
  exit /b 1
)
echo.
echo  ==============================
echo      S E R R E N Y A  D I C E
echo  ==============================
echo.
echo App-Adresse: http://localhost:3000
echo Das Fenster offen lassen, waehrend ihr spielt.
echo.
start "Browser starten" cmd /c "timeout /t 2 >nul & start http://localhost:3000"
node server.js
pause
