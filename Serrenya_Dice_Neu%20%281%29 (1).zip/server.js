'use strict';
/** Serrenya Dice: dependency-free HTTP + WebSocket multiplayer server. Node.js >= 20. */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { randomInt, randomBytes } = crypto;
const HOST = process.env.HOST || '0.0.0.0';
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.join(__dirname, 'public');
const rooms = new Map();
const roomCreates = new Map();
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const SIDES = new Set([4, 6, 8, 10, 12, 20, 100]);
const COLOR = /^#[0-9a-fA-F]{6}$/;
const DEFAULT_STYLE = Object.freeze({ base:'#2d2450', edge:'#e8b96b', ink:'#fff4d8', glow:'#a783ef', finish:'arcane', metalness:0.52, material:'gem', pattern:'runes', numerals:'ancient', smoothness:.78, aura:.66, bevel:.56, grain:.16, iridescence:.32 });
const DEFAULT_PHYSICS = Object.freeze({ gravity:17, bounce:0.43, friction:0.31, force:8, spin:10, duration:2900, maxVisible:12 });
const CONTENT_TYPES = { '.html':'text/html; charset=utf-8', '.js':'application/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.ico':'image/x-icon', '.webp':'image/webp', '.json':'application/json; charset=utf-8', '.webmanifest':'application/manifest+json' };
function clamp(x, min, max, fallback) { const n = Number(x); return Number.isFinite(n) ? Math.min(max,Math.max(min,n)) : fallback; }
function styleOf(value) {
 const a=value&&typeof value==='object'&&!Array.isArray(value)?value:{};
 const one=(name,allowed)=>allowed.includes(a[name])?a[name]:DEFAULT_STYLE[name];
 const color=name=>COLOR.test(a[name])?a[name]:DEFAULT_STYLE[name];
 return {
   base:color('base'),edge:color('edge'),ink:color('ink'),glow:color('glow'),
   finish:one('finish',['arcane','obsidian','ember','frost','forest','royal','brass','crystal','bone','bloodmoon','custom']),
   material:one('material',['gem','metal','stone','crystal','wood','bone']),
   pattern:one('pattern',['none','runes','stars','veins','carved','scales']),
   numerals:one('numerals',['classic','ancient','modern']),
   metalness:clamp(a.metalness,0,1,DEFAULT_STYLE.metalness),
   smoothness:clamp(a.smoothness,0,1,DEFAULT_STYLE.smoothness),
   aura:clamp(a.aura,0,1,DEFAULT_STYLE.aura),
   bevel:clamp(a.bevel,0,1,DEFAULT_STYLE.bevel),
   grain:clamp(a.grain,0,1,DEFAULT_STYLE.grain),
   iridescence:clamp(a.iridescence,0,1,DEFAULT_STYLE.iridescence)
 };
}
function physicsOf(value) { const a = value && typeof value === 'object' && !Array.isArray(value) ? value : {}; return { gravity:clamp(a.gravity,2,32,DEFAULT_PHYSICS.gravity), bounce:clamp(a.bounce,.02,.98,DEFAULT_PHYSICS.bounce), friction:clamp(a.friction,.01,1,DEFAULT_PHYSICS.friction), force:clamp(a.force,2,17,DEFAULT_PHYSICS.force), spin:clamp(a.spin,1,25,DEFAULT_PHYSICS.spin), duration:Math.round(clamp(a.duration,1200,6000,DEFAULT_PHYSICS.duration)), maxVisible:Math.round(clamp(a.maxVisible,1,24,DEFAULT_PHYSICS.maxVisible)) }; }
function nameOf(input) { return typeof input === 'string' ? (input.replace(/[\u0000-\u001F\u007F]/g,'').trim().slice(0,26) || 'Abenteurer') : 'Abenteurer'; }
function roomCode() { let c; do { c = Array.from({length:6},()=>ALPHABET[randomInt(ALPHABET.length)]).join(''); } while(rooms.has(c)); return c; }
function safeEqual(a,b) { if(typeof a!=='string'||typeof b!=='string')return false; const x=Buffer.from(a),y=Buffer.from(b); return x.length===y.length&&crypto.timingSafeEqual(x,y); }
function publicRoom(room) { return { code:room.code, physics:room.physics, members:[...room.members.values()].map(m=>({id:m.id,name:m.name,role:m.role})), recent:room.recent.slice(-20), hostOnline:!!room.hostId, createdAt:room.createdAt }; }
function rollDice(sides,count,style) {
  const dice=[]; let total=0;
  for(let i=0;i<count;i++) {
    // randomInt uses rejection sampling: every valid side has exactly the same probability.
    const value=randomInt(1,sides+1); total+=value;
    if(sides===100) { const shown=value%100, tens=Math.floor(shown/10), ones=shown%10; dice.push({sides:10,faceIndex:tens,label:String(tens*10).padStart(2,'0'),style,percentile:i}); dice.push({sides:10,faceIndex:ones,label:String(ones),style,percentile:i}); }
    else dice.push({sides,faceIndex:value-1,label:String(value),style});
  }
  return {dice,total};
}
function json(res,status,data) { const body=JSON.stringify(data); res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(body); }
function readJson(req) { return new Promise((resolve,reject)=>{ let buf=''; req.on('data',chunk=>{buf+=chunk;if(buf.length>12000){reject(new Error('Anfrage zu gross'));req.destroy();}});req.on('end',()=>{try{resolve(buf?JSON.parse(buf):{});}catch{reject(new Error('Ungültige JSON-Daten'));}});req.on('error',reject); }); }
const server = http.createServer(async (req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Content-Security-Policy',"default-src 'self'; connect-src 'self' ws: wss:; img-src 'self' data: https://api.qrserver.com; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'self'");
  let url; try{url=new URL(req.url,'http://localhost');}catch{return json(res,400,{error:'Ungültige URL'});}
  if(req.method==='GET'&&url.pathname==='/health')return json(res,200,{ok:true,rooms:rooms.size});
  if(req.method==='POST'&&url.pathname==='/api/rooms') {
    const addr=req.socket.remoteAddress||'unknown';const now=Date.now();const prev=roomCreates.get(addr)||[];const history=prev.filter(v=>now-v<60000);if(history.length>=10)return json(res,429,{error:'Bitte kurz warten, bevor du einen weiteren Raum erstellst.'});history.push(now);roomCreates.set(addr,history);
    if(rooms.size>=2000)return json(res,503,{error:'Zurzeit sind zu viele Räume aktiv.'});
    const code=roomCode(),token=randomBytes(32).toString('hex'); rooms.set(code,{code,hostToken:token,hostId:null,members:new Map(),physics:{...DEFAULT_PHYSICS},recent:[],createdAt:now,updatedAt:now});return json(res,201,{code,hostToken:token});
  }
  const match=url.pathname.match(/^\/api\/rooms\/([A-Z0-9]{6})$/i);
  if(req.method==='GET'&&match){const room=rooms.get(match[1].toUpperCase());return room?json(res,200,{code:room.code,hostOnline:!!room.hostId}):json(res,404,{error:'Raum nicht gefunden'});}
  if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Methode nicht erlaubt'});
  let p=url.pathname==='/'?'/index.html':url.pathname;
  try{p=decodeURIComponent(p);}catch{return json(res,400,{error:'Ungültiger Pfad'});}
  const file=path.resolve(ROOT,'.'+p);
  if(!file.startsWith(ROOT+path.sep))return json(res,403,{error:'Zugriff verweigert'});
  try{const st=await fs.promises.stat(file);if(!st.isFile())throw new Error('not a file');res.writeHead(200,{'Content-Type':CONTENT_TYPES[path.extname(file)]||'application/octet-stream','Cache-Control':'public, max-age=3600'});if(req.method==='HEAD')return res.end();fs.createReadStream(file).pipe(res);}catch{json(res,404,{error:'Datei nicht gefunden'});}
});

// RFC 6455 WebSocket frame implementation. Supports browser text frames, pings and close.
const clients=new Map();
function frame(opcode,payload=Buffer.alloc(0)) { if(!Buffer.isBuffer(payload))payload=Buffer.from(payload);const length=payload.length;const head=length<126?Buffer.alloc(2):length<65536?Buffer.alloc(4):Buffer.alloc(10);head[0]=0x80|opcode;if(length<126)head[1]=length;else if(length<65536){head[1]=126;head.writeUInt16BE(length,2);}else{head[1]=127;head.writeBigUInt64BE(BigInt(length),2);}return Buffer.concat([head,payload]); }
function send(c,type,payload={}) { if(!c||c.closed||c.socket.destroyed)return;try{c.socket.write(frame(1,JSON.stringify({type,...payload})));}catch{close(c);} }
function broadcast(room,type,payload){for(const id of room.members.keys())send(clients.get(id),type,payload);}
function leave(c){const code=c.roomCode;if(!code)return;c.roomCode=null;const room=rooms.get(code);if(!room)return;room.members.delete(c.id);if(room.hostId===c.id)room.hostId=null;room.updatedAt=Date.now();broadcast(room,'room:members',{members:publicRoom(room).members,hostOnline:!!room.hostId});}
function close(c){if(c.closed)return;c.closed=true;leave(c);clients.delete(c.id);try{c.socket.destroy();}catch{}}
function ack(c,req,ok,payload={}){send(c,'ack',{ref:typeof req==='string'?req:null,ok,...payload});}
function onMessage(c,raw){let msg;try{msg=JSON.parse(raw);}catch{return send(c,'error',{error:'Ungültige Nachricht'});}if(!msg||typeof msg!=='object')return;
 const t=msg.type,ref=msg.ref,p=msg.payload||{};if(typeof t!=='string'||t.length>70)return;
 if(t==='room:join') {
   const room=rooms.get(String(p.code||'').trim().toUpperCase());if(!room)return ack(c,ref,false,{error:'Raum nicht gefunden. Prüfe den Code.'});
   const role=p.role==='host'?'host':'player';if(role==='host'&&!safeEqual(p.token,room.hostToken))return ack(c,ref,false,{error:'Kein Zugriff auf das Hauptdisplay.'});
   if(room.members.size>=40&&c.roomCode!==room.code)return ack(c,ref,false,{error:'Der Raum ist voll (40 Geräte).'});
   leave(c);c.roomCode=room.code;c.role=role;c.name=role==='host'?'Spielleitung':nameOf(p.name);c.lastRoll=0;room.members.set(c.id,{id:c.id,role,name:c.name});if(role==='host')room.hostId=c.id;room.updatedAt=Date.now();ack(c,ref,true,{id:c.id,room:publicRoom(room)});broadcast(room,'room:members',{members:publicRoom(room).members,hostOnline:!!room.hostId});return;
 }
 const room=rooms.get(c.roomCode);if(!room||!room.members.has(c.id))return ack(c,ref,false,{error:'Bitte zuerst einem Raum beitreten.'});
 if(t==='room:settings'){if(room.hostId!==c.id)return ack(c,ref,false,{error:'Nur die Spielleitung darf die Physik ändern.'});room.physics=physicsOf(p);room.updatedAt=Date.now();broadcast(room,'room:settings',{physics:room.physics});return ack(c,ref,true);}
 if(t==='room:clear'){if(room.hostId!==c.id)return ack(c,ref,false,{error:'Nur die Spielleitung darf den Verlauf löschen.'});room.recent=[];broadcast(room,'room:cleared',{});return ack(c,ref,true);}
 if(t==='roll:request'){
   if(Date.now()-c.lastRoll<800)return ack(c,ref,false,{error:'Einen kurzen Moment zwischen den Würfen lassen.'});
   const sides=Number(p.sides),count=Number(p.count);if(!SIDES.has(sides))return ack(c,ref,false,{error:'Unbekannter Würfeltyp.'});if(!Number.isInteger(count)||count<1||count>8)return ack(c,ref,false,{error:'Wähle 1 bis 8 Würfel.'});
   const style=styleOf(p.style),rolled=rollDice(sides,count,style),now=Date.now();const event={id:randomBytes(10).toString('hex'),playerId:c.id,name:c.name,notation:`${count}W${sides}`,count,sides,total:rolled.total,dice:rolled.dice,physics:{...room.physics},createdAt:now};
   c.lastRoll=now;room.updatedAt=now;room.recent.push({id:event.id,playerId:c.id,name:c.name,notation:event.notation,total:event.total,createdAt:now,dice:event.dice.map(d=>d.label)});if(room.recent.length>30)room.recent.shift();broadcast(room,'roll:started',{roll:event});return ack(c,ref,true,{id:event.id,total:event.total});
 }
 if(t==='room:ping')return ack(c,ref,true);
 ack(c,ref,false,{error:'Unbekannter Befehl'});
}
function processFrames(c){let b=c.buffer;for(;;){if(b.length<2)break;const first=b[0],op=first&15,fin=!!(first&128),masked=!!(b[1]&128);let len=b[1]&127,off=2;if(len===126){if(b.length<4)break;len=b.readUInt16BE(2);off=4;}else if(len===127){if(b.length<10)break;const big=b.readBigUInt64BE(2);if(big>16384n)return close(c);len=Number(big);off=10;}if(len>16384||!masked)return close(c);if(b.length<off+4+len)break;const mask=b.subarray(off,off+4),data=Buffer.from(b.subarray(off+4,off+4+len));for(let i=0;i<len;i++)data[i]^=mask[i&3];b=b.subarray(off+4+len);if(op===8){close(c);return;}if(op===9){c.socket.write(frame(10,data));continue;}if(op===10){c.lastPong=Date.now();continue;}if(op!==1||!fin)return close(c);onMessage(c,data.toString('utf8'));}c.buffer=b;}
server.on('upgrade',(req,socket,head)=>{
 let url;try{url=new URL(req.url,'http://localhost');}catch{return socket.destroy();}const key=req.headers['sec-websocket-key'];if(url.pathname!=='/ws'||req.headers.upgrade?.toLowerCase()!=='websocket'||typeof key!=='string'||Buffer.from(key,'base64').length!==16){socket.destroy();return;}
 const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');const c={id:randomBytes(10).toString('hex'),socket,buffer:Buffer.alloc(0),roomCode:null,role:null,name:null,closed:false,lastRoll:0,lastPong:Date.now()};clients.set(c.id,c);socket.setNoDelay(true);socket.on('data',chunk=>{c.buffer=Buffer.concat([c.buffer,chunk]);if(c.buffer.length>35000)return close(c);processFrames(c);});socket.on('close',()=>close(c));socket.on('error',()=>close(c));if(head.length){c.buffer=Buffer.from(head);processFrames(c);}
});
const maintain=setInterval(()=>{const now=Date.now();for(const [c,room] of rooms){if(!room.members.size&&now-room.updatedAt>3*60*60*1000)rooms.delete(c);}for(const [ip,t] of roomCreates)if(t.every(x=>now-x>60000))roomCreates.delete(ip);for(const c of clients.values()){if(now-c.lastPong>80000){close(c);continue;}try{c.socket.write(frame(9,Buffer.from('p')));}catch{close(c);}}},25000);maintain.unref();
if(require.main===module)server.listen(PORT,HOST,()=>console.log(`\n  ✦ SERRENYA DICE ✦\n  http://localhost:${PORT}\n  Online-Freigabe: siehe README.md\n`));
module.exports={server,rooms,rollDice,styleOf,physicsOf,publicRoom,close};
