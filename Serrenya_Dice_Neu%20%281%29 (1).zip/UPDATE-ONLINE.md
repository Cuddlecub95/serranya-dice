# Serrenya Dice 2.0 – Upgrade der bestehenden Online-App

## Bestehende Online-App
- https://serrenya-dice-play.onrender.com
- GitHub: https://github.com/Cuddlecub95/serranya-dice
- Render-Service: `serrenya-dice-play`

## Warum muss die ZIP-Datei in GitHub ersetzt werden?
In deinem GitHub-Repository befindet sich derzeit nur das Archiv `Serrenya_Dice_Neu (1).zip`. Beim Deployment wird dieses Archiv über den Render-Buildbefehl entpackt. Die neue Version muss deshalb denselben Archivnamen tragen.

## So aktualisierst du die App ohne Programmieren
1. Lade die aktualisierte Datei `Serrenya_Dice_Neu (1).zip` herunter.
2. Öffne https://github.com/Cuddlecub95/serranya-dice und melde dich an.
3. Entferne das bisherige ZIP aus dem Repository (Datei öffnen -> ... -> Delete file -> Commit changes), falls GitHub kein direktes Überschreiben erlaubt.
4. Wähle `Add file` -> `Upload files` und lade das **neue** Archiv `Serrenya_Dice_Neu (1).zip` hoch (nicht entpacken). Prüfe, dass der Dateiname exakt so lautet.
5. Klicke `Commit changes`. Wenn Render nicht von selbst neu deployt, öffne den Service `serrenya-dice-play` im Render Dashboard und wähle `Manual Deploy` -> `Deploy latest commit`.
6. Warte, bis Render den Status `Live` meldet. Öffne danach https://serrenya-dice-play.onrender.com und lade die Seite einmal mit Strg+F5 neu.

**Wichtig:** Lade keine Datei mit einem zusätzlichen Suffix wie `(2)` hoch. Der aktuelle Render-Buildbefehl sucht exakt nach `Serrenya_Dice_Neu (1).zip`.

## Version 2.0
- Fantasy-Taverne mit Kerzenschein, Eichenholz, verziertem Würfeltisch und moosgrünem Leder
- hochwertige Facettenbeleuchtung, metallisch gravierte Kanten, diffuse und Kontaktschatten, Materialtexturen
- realistischere Wurfbewegung mit ballistischen Sprüngen, mehreren Aufprallphasen, Energieverlust und dem Ausrollen der Würfel
- 10 Designvorlagen, 6 Materialtypen, 6 Oberflächenmuster, 3 Schriftstile
- individuelle Farbe, Kante, Schriftfarbe, Aura, metallischer Glanz, Oberflächenglätte, Kantenschliff, Patina und Perlmutt
- Qualitätsstufen `Automatisch`, `Hoch`, `Ultra` und `Energiesparen`
- Serverzufall (Node.js `crypto.randomInt`) bleibt unverändert; die Darstellung beeinflusst niemals das Ergebnis
- 8 erfolgreiche automatisierte Tests

Die Rendering-Pipeline ist weiterhin ein leichter, eigenständiger 3D-Mesh-Renderer auf HTML-Canvas; sie ist **keine** vollständige GPU-basierte Raytracing-/Rigid-Body-Engine. Die physikalisch inspirierte Animation besitzt eine kontrollierte Zielausrichtung, damit das serveryseitig gezogene Ergebnis sichtbar bleibt.
