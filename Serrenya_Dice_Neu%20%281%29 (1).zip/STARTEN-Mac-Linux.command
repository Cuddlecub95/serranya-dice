#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js >=20 installieren: https://nodejs.org/'
  exit 1
fi
( sleep 2; if command -v open >/dev/null 2>&1; then open http://localhost:3000; elif command -v xdg-open >/dev/null 2>&1; then xdg-open http://localhost:3000; fi ) &
node server.js
