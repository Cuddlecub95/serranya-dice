'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const drawingMethods=['setTransform','clearRect','fillRect','strokeRect','beginPath','closePath','moveTo','lineTo','bezierCurveTo','arc','fill','stroke','save','restore','clip','translate','scale','fillText','strokeText','roundRect'];
function fakeCanvas(){
 const counts={};const context={};for(const name of drawingMethods)context[name]=()=>{counts[name]=(counts[name]||0)+1;};
 context.createRadialGradient=context.createLinearGradient=()=>({addColorStop(){}});
 const canvas={width:0,height:0,getContext:()=>context,getBoundingClientRect:()=>({width:640,height:500})};
 return {canvas,counts};
}
const vmContext={window:{},requestAnimationFrame:()=>2,cancelAnimationFrame(){},performance:{now:()=>5000},devicePixelRatio:1.6,Math,Set,Number,String};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../public/dice-engine.js'),'utf8'),vmContext);
const {DiceStage,setQuality}=vmContext.window.SerrenyaDiceEngine;
test('Ultra canvas rendering and all six polyhedron meshes with material patterns',()=>{
 const {canvas,counts}=fakeCanvas();const stage=new DiceStage(canvas,{preview:true});
 setQuality('ultra');stage.resize();assert.ok(canvas.width>=640);assert.ok(canvas.height>=500);
 for(const sides of [4,6,8,10,12,20]){
  for(const material of ['gem','metal','stone','wood','bone','crystal']){
   for(const pattern of ['none','runes','stars','veins','carved','scales']){
    stage.setPreview(sides,{base:'#493056',edge:'#e8b96b',ink:'#ffffff',glow:'#967af1',material,pattern,metalness:.6,grain:.4,aura:.7,bevel:.8,smoothness:.9,iridescence:.5});
    stage.drawPreview(stage.ctx,640,500,5100);
   }
  }
 }
 assert.ok(counts.fill>800);assert.ok(counts.stroke>800);stage.destroy();
});
test('Thrown dice settle with predetermined server result independently of animation',()=>{
 const {canvas,counts}=fakeCanvas();const stage=new DiceStage(canvas);stage.resize();
 stage.addRoll({id:'test-roll',name:'Ybria',physics:{duration:2900,bounce:.5,gravity:18,friction:.4,force:8,spin:12,maxVisible:12},dice:[
  {sides:20,faceIndex:19,label:'20',style:{base:'#764f30',edge:'#ffe5a2',ink:'#ffffff',glow:'#db8941',material:'metal',pattern:'runes'}},
  {sides:10,faceIndex:0,label:'00',percentile:1,style:{material:'crystal'}},
  {sides:10,faceIndex:5,label:'5',percentile:1,style:{material:'stone'}}
 ]});
 assert.equal(stage.dice.length,3);stage.drawBoard(stage.ctx,640,500,6400);stage.drawBoard(stage.ctx,640,500,99999);
 assert.ok(counts.fill>5);stage.destroy();
});
test('Advanced style settings are sanitized server-side',()=>{
 const {styleOf}=require('../server');
 const s=styleOf({material:'crystal',pattern:'scales',numerals:'ancient',smoothness:9,grain:-5,iridescence:Infinity,base:'#112233'});
 assert.equal(s.material,'crystal');assert.equal(s.pattern,'scales');assert.equal(s.smoothness,1);assert.equal(s.grain,0);assert.equal(s.iridescence,.32);assert.equal(s.base,'#112233');
 assert.equal(styleOf({material:'script',pattern:'javascript:evil'}).pattern,'runes');
});
