'use strict';
const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const {server,rooms,rollDice,styleOf,physicsOf}=require('../server');
let base, wsbase;
const connections=[];
async function boot(){if(!server.listening)await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const port=server.address().port;base='http://127.0.0.1:'+port;wsbase='ws://127.0.0.1:'+port+'/ws';}
async function client(){const socket=new WebSocket(wsbase);await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});connections.push(socket);const pending=new Map(),events=[];let n=0;socket.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.type==='ack'){const p=pending.get(m.ref);if(p){pending.delete(m.ref);p(m);}}else{events.push(m);for(const fn of listeners){if(m.type===fn.type){fn.resolve(m);listeners.delete(fn);}}}});const listeners=new Set();return {socket,events,request(type,payload){return new Promise((resolve,reject)=>{const ref='r'+(++n);pending.set(ref,resolve);socket.send(JSON.stringify({type,ref,payload}));setTimeout(()=>{if(pending.has(ref)){pending.delete(ref);reject(new Error('Timeout: '+type));}},4000).unref();});},waitEvent(type){const prior=events.find(x=>x.type===type);if(prior)return Promise.resolve(prior);return new Promise((resolve,reject)=>{const a={type,resolve};listeners.add(a);setTimeout(()=>{if(listeners.has(a)){listeners.delete(a);reject(new Error('Timeout event '+type));}},4000).unref();});}};}
after(async()=>{for(const c of connections)try{c.close();}catch{};await new Promise(resolve=>server.close(resolve));});
test('correct die geometries: W4, W6, W8, W10, W12, W20',()=>{const context={window:{},requestAnimationFrame:()=>0,performance:{now:()=>0}};vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../public/dice-engine.js'),'utf8'),context);const faces=JSON.parse(JSON.stringify(context.window.SerrenyaDiceEngine.faceCounts));assert.deepEqual(faces,{'4':4,'6':6,'8':8,'10':10,'12':12,'20':20});});
test('server RNG always in range and uses 2 W10 for a percentile die',()=>{for(const sides of [4,6,8,10,12,20,100]){const samples=new Set();for(let k=0;k<250;k++){const roll=rollDice(sides,1,styleOf());assert.ok(roll.total>=1&&roll.total<=sides);assert.equal(roll.dice.length,sides===100?2:1);samples.add(roll.total);}assert.ok(samples.size>=Math.min(4,sides));}});
test('style and physics inputs sanitised and clamped',()=>{const s=styleOf({base:'red',edge:'#112233',metalness:999,finish:'not-real'});assert.equal(s.base,'#2d2450');assert.equal(s.edge,'#112233');assert.equal(s.metalness,1);assert.equal(s.finish,'arcane');const p=physicsOf({gravity:-100,bounce:4,maxVisible:999,duration:-1});assert.equal(p.gravity,2);assert.equal(p.bounce,.98);assert.equal(p.maxVisible,24);assert.equal(p.duration,1200);});
test('create room, host+player join, live event, permissions and history',async()=>{
 await boot();const response=await fetch(base+'/api/rooms',{method:'POST'});assert.equal(response.status,201);const created=await response.json();assert.match(created.code,/^[A-Z2-9]{6}$/);assert.equal(created.hostToken.length,64);
 const host=await client();const player=await client();const unauthorized=await client();
 assert.equal((await unauthorized.request('room:join',{code:created.code,role:'host',token:'invalid'})).ok,false);
 const h=await host.request('room:join',{code:created.code,role:'host',token:created.hostToken});assert.equal(h.ok,true);assert.equal(h.room.code,created.code);
 const p=await player.request('room:join',{code:created.code,role:'player',name:'Vaelor'});assert.equal(p.ok,true);assert.equal(p.room.members.length,2);
 const change=await player.request('room:settings',{gravity:32});assert.equal(change.ok,false);
 const updated=await host.request('room:settings',{gravity:22,bounce:.8,maxVisible:7});assert.equal(updated.ok,true);assert.equal(rooms.get(created.code).physics.maxVisible,7);
 const roll=await player.request('roll:request',{sides:20,count:3,style:{base:'#fedcba'}});assert.equal(roll.ok,true);
 const event=await host.waitEvent('roll:started');assert.equal(event.roll.name,'Vaelor');assert.equal(event.roll.dice.length,3);assert.equal(event.roll.dice.reduce((a,b)=>a+Number(b.label),0),event.roll.total);assert.equal(event.roll.physics.gravity,22);
 const pEvent=await player.waitEvent('roll:started');assert.equal(pEvent.roll.id,event.roll.id);
 const responseRoom=await fetch(base+'/api/rooms/'+created.code);assert.equal((await responseRoom.json()).hostOnline,true);
 assert.equal(rooms.get(created.code).recent.length,1);
 assert.equal((await host.request('room:clear',{})).ok,true);assert.equal(rooms.get(created.code).recent.length,0);
});
test('static site, health and path traversal protection',async()=>{await boot();let r=await fetch(base+'/');assert.equal(r.status,200);assert.match(await r.text(),/Schmiede dein/);r=await fetch(base+'/dice-engine.js');assert.equal(r.status,200);assert.match(await r.text(),/DiceStage/);r=await fetch(base+'/health');assert.equal((await r.json()).ok,true);r=await fetch(base+'/no-such-file');assert.equal(r.status,404);});
